import { useState } from "react";
import { motion } from "motion/react";
import {
  Activity,
  Axe,
  Compass,
  Heart,
  Pickaxe,
  Play,
  RotateCw,
  Shield,
  Square,
  Trees,
  UserCheck,
  Utensils,
  Zap,
} from "lucide-react";
import { BotConfig, BotStateSnapshot, BotTaskMode } from "../types";

interface OverviewPanelProps {
  state: BotStateSnapshot;
  formConfig: BotConfig;
  onChangeConfig: (next: Partial<BotConfig>) => void;
  onSaveConfig: () => Promise<void>;
  onConnect: () => Promise<void>;
  onDisconnect: () => Promise<void>;
  onSetTask: (
    task: BotTaskMode,
    targetPlayer?: string,
    targetCount?: number | null
  ) => Promise<void>;
  isBusy: boolean;
}

const HERO_IMAGE = "/src/assets/images/minecraft_workshop_hero_1795511751486.jpg";
const AVATAR_IMAGE = "/src/assets/images/companion_voxel_avatar_1795511751014.jpg";
const EASE = [0.22, 1, 0.36, 1] as const;

function formatUptime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return [h, m, s].map((v) => String(v).padStart(2, "0")).join(":");
}

function getStatusMeta(status: BotStateSnapshot["status"]) {
  switch (status) {
    case "online":
      return { label: "Serverda faol", color: "text-emerald-400", dot: "bg-emerald-400" };
    case "connecting":
      return { label: "Ulanilmoqda", color: "text-[#E3A074]", dot: "bg-[#D97757]" };
    case "reconnecting":
      return { label: "24/7 Qayta ulanish", color: "text-[#E3A074]", dot: "bg-[#D97757]" };
    case "error":
      return { label: "Ulanish xatosi", color: "text-rose-400", dot: "bg-rose-400" };
    default:
      return { label: "Ulanmagan", color: "text-[#A6A39B]", dot: "bg-[#6E6B64]" };
  }
}

export function OverviewPanel({
  state,
  formConfig,
  onChangeConfig,
  onSaveConfig,
  onConnect,
  onDisconnect,
  onSetTask,
  isBusy,
}: OverviewPanelProps) {
  const [heroError, setHeroError] = useState(false);
  const [avatarError, setAvatarError] = useState(false);

  const statusMeta = getStatusMeta(state.status);
  const isConnectedOrTrying =
    state.status === "online" ||
    state.status === "connecting" ||
    state.status === "reconnecting";

  const quickTasks: Array<{
    id: BotTaskMode;
    label: string;
    icon: typeof Zap;
  }> = [
    { id: "speedrun", label: "Speedrun", icon: Zap },
    { id: "chop_wood", label: "Daraxt chopish", icon: Trees },
    { id: "follow_player", label: "Orqamdan yurish", icon: UserCheck },
    { id: "mine_ores", label: "Kon qazish", icon: Pickaxe },
    { id: "guard", label: "Qo'riqlash", icon: Shield },
    { id: "idle", label: "To'xtatish", icon: Square },
  ];

  const metrics = [
    {
      label: "Jon va Ochlik",
      icon: Heart,
      primary: `${state.health}/20`,
      secondary: `${state.food}/20`,
      secondaryIcon: Utensils,
    },
    {
      label: "Koordinatalar",
      icon: Compass,
      primary: state.position
        ? `${state.position.x}, ${state.position.y}, ${state.position.z}`
        : "— , — , —",
    },
    {
      label: "24/7 Ishlash vaqti",
      icon: Activity,
      primary: formatUptime(state.uptimeSeconds),
    },
    {
      label: "Qazilgan / Qayta ulanish",
      icon: RotateCw,
      primary: String(state.blocksMinedCount),
      secondary: `${state.reconnectCount} marta ulangan`,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Main 2-Column Balanced Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left: Server & Cracked Account Config */}
        <motion.section
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.32, ease: EASE }}
          className="lg:col-span-7 bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl p-6 flex flex-col justify-between shadow-[0_0_0_1px_rgba(255,255,255,0.02)]"
        >
          <div className="space-y-5">
            <div className="flex items-start justify-between gap-4 border-b border-[#2C2B28] pb-4">
              <div>
                <h1 className="text-2xl font-medium text-[#F5F4ED]">
                  Server va Cracked Akkount
                </h1>
                <p className="text-sm text-[#A6A39B] mt-1">
                  Litsenziyasiz (Cracked) akkount orqali istalgan server yoki e4mc linkiga ulaning.
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs font-medium shrink-0 pt-1">
                <span className={`w-2 h-2 rounded-full ${statusMeta.dot}`} />
                <span className={statusMeta.color}>{statusMeta.label}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-[#C5C2BA] mb-1.5">
                  Server manzili (Link yoki IP:Port)
                </label>
                <input
                  type="text"
                  value={formConfig.serverLink}
                  onChange={(e) => onChangeConfig({ serverLink: e.target.value })}
                  placeholder="scrubbed-bust.eu.e4mc.link"
                  className="w-full px-3.5 py-2.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm font-mono text-[#F5F4ED] placeholder:text-[#6E6B64] focus:outline-none focus:border-[#D97757] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C5C2BA] mb-1.5">
                  Bot niki (Cracked / Offline)
                </label>
                <input
                  type="text"
                  maxLength={16}
                  value={formConfig.username}
                  onChange={(e) => onChangeConfig({ username: e.target.value })}
                  placeholder="Alpomish_AI"
                  className="w-full px-3.5 py-2.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm font-mono text-[#F5F4ED] placeholder:text-[#6E6B64] focus:outline-none focus:border-[#D97757] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C5C2BA] mb-1.5">
                  Minecraft versiyasi
                </label>
                <input
                  type="text"
                  value={formConfig.versionLabel}
                  onChange={(e) => onChangeConfig({ versionLabel: e.target.value })}
                  placeholder="1.21.11 fabric"
                  className="w-full px-3.5 py-2.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm font-mono text-[#F5F4ED] placeholder:text-[#6E6B64] focus:outline-none focus:border-[#D97757] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C5C2BA] mb-1.5">
                  Launcher / Cracked moslashuv
                </label>
                <select
                  value={formConfig.launcherType}
                  onChange={(e) =>
                    onChangeConfig({
                      launcherType: e.target.value as BotConfig["launcherType"],
                    })
                  }
                  className="w-full px-3.5 py-2.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm text-[#F5F4ED] focus:outline-none focus:border-[#D97757] transition-colors"
                >
                  <option value="tlauncher">TLauncher (Cracked / Offline)</option>
                  <option value="sklauncher">SKLauncher (Cracked / Offline)</option>
                  <option value="legacy">Legacy Launcher (Cracked)</option>
                  <option value="prism">Prism / Modrinth Offline</option>
                  <option value="direct_bot">To'g'ridan-to'g'ri Bot (Launchersiz)</option>
                  <option value="other">Boshqa istalgan Launcher</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#C5C2BA] mb-1.5">
                  Server paroli (/login, ixtiyoriy)
                </label>
                <input
                  type="password"
                  value={formConfig.authPassword}
                  onChange={(e) => onChangeConfig({ authPassword: e.target.value })}
                  placeholder="AuthMe bo'lsa parol yozing"
                  className="w-full px-3.5 py-2.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm text-[#F5F4ED] placeholder:text-[#6E6B64] focus:outline-none focus:border-[#D97757] transition-colors"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-[#C5C2BA] mb-1.5">
                  Orqasidan yuriladigan o'yinchi (ixtiyoriy)
                </label>
                <input
                  type="text"
                  value={formConfig.followTarget}
                  onChange={(e) => onChangeConfig({ followTarget: e.target.value })}
                  placeholder="Masalan: Jasur_UZ"
                  className="w-full px-3.5 py-2.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm text-[#F5F4ED] placeholder:text-[#6E6B64] focus:outline-none focus:border-[#D97757] transition-colors"
                />
              </div>
            </div>

            {/* Clean Tactile Toggle Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {[
                {
                  label: "24/7 Avto Qayta Ulanish",
                  value: formConfig.autoReconnect247,
                  onToggle: () =>
                    onChangeConfig({ autoReconnect247: !formConfig.autoReconnect247 }),
                },
                {
                  label: "Faqat nomi aytilganda javob berish",
                  value: formConfig.respondOnlyWhenAddressed,
                  onToggle: () =>
                    onChangeConfig({
                      respondOnlyWhenAddressed: !formConfig.respondOnlyWhenAddressed,
                    }),
                },
                {
                  label: "O'yin chatiga ham yozish",
                  value: formConfig.relayAiToGameChat,
                  onToggle: () =>
                    onChangeConfig({ relayAiToGameChat: !formConfig.relayAiToGameChat }),
                },
                {
                  label: "Simple Voice Chat (Mod)",
                  value: formConfig.useSimpleVoiceChat,
                  onToggle: () =>
                    onChangeConfig({
                      useSimpleVoiceChat: !formConfig.useSimpleVoiceChat,
                    }),
                },
              ].map((toggle) => (
                <motion.button
                  key={toggle.label}
                  type="button"
                  whileTap={{ scale: 0.985 }}
                  onClick={toggle.onToggle}
                  className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl border text-left text-xs transition-colors ${
                    toggle.value
                      ? "bg-[#D97757]/12 border-[#D97757]/55 text-[#F5F4ED]"
                      : "bg-[#141413] border-[#2C2B28] text-[#9E9B93] hover:border-[#3D3B36]"
                  }`}
                >
                  <span className="font-medium">{toggle.label}</span>
                  <span
                    className={`font-mono tabular-nums ${
                      toggle.value ? "text-[#E59377]" : "text-[#6E6B64]"
                    }`}
                  >
                    {toggle.value ? "YOQILGAN" : "O'CHIQ"}
                  </span>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Action Footer */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-6 mt-6 border-t border-[#2C2B28]">
            <p className="text-xs text-[#A6A39B] max-w-md">{state.statusMessage}</p>
            <div className="flex items-center gap-3 shrink-0">
              <motion.button
                type="button"
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.98 }}
                disabled={isBusy}
                onClick={onSaveConfig}
                className="px-4 py-2 text-sm font-medium text-[#E5E3DC] bg-[#292825] hover:bg-[#34322E] border border-[#3B3934] rounded-xl transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
              >
                Saqlash
              </motion.button>
              {isConnectedOrTrying ? (
                <motion.button
                  type="button"
                  whileHover={{ y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isBusy}
                  onClick={onDisconnect}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-rose-600 hover:bg-rose-500 rounded-xl transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
                >
                  <Square className="w-4 h-4" />
                  <span>Botni Uzish</span>
                </motion.button>
              ) : (
                <motion.button
                  type="button"
                  whileHover={{ y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isBusy}
                  onClick={onConnect}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-[#141413] bg-[#D97757] hover:bg-[#E38567] rounded-xl transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
                >
                  <Play className="w-4 h-4" />
                  <span>Serverga Ulash</span>
                </motion.button>
              )}
            </div>
          </div>
        </motion.section>

        {/* Right: Companion Identity & Live Visual Panel */}
        <motion.section
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.36, delay: 0.06, ease: EASE }}
          className="lg:col-span-5 bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl overflow-hidden flex flex-col"
        >
          <div className="relative h-48 sm:h-52 w-full bg-[#121211] overflow-hidden">
            {!heroError ? (
              <img
                src={HERO_IMAGE}
                alt="Minecraft voxel o'rmon maydoni va dastgoh"
                referrerPolicy="no-referrer"
                onError={() => setHeroError(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-[#1C1B1A] via-[#2B201B] to-[#141413] flex items-center justify-center">
                <Axe className="w-10 h-10 text-[#D97757]/70" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-[#1C1B1A] via-[#1C1B1A]/45 to-transparent" />

            <div className="absolute bottom-4 left-5 right-5 flex items-end gap-3.5">
              <div className="w-14 h-14 rounded-xl overflow-hidden border border-[#3E3C37] bg-[#141413] shrink-0">
                {!avatarError ? (
                  <img
                    src={AVATAR_IMAGE}
                    alt="Alpomish AI yordamchi"
                    referrerPolicy="no-referrer"
                    onError={() => setAvatarError(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-[#262522] text-[#D97757] font-bold">
                    AI
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <h2 className="text-xl font-medium text-[#F5F4ED] truncate">
                  {state.config.username}
                </h2>
                <div className="flex items-center gap-2 text-xs text-[#D1CEC5]">
                  <span>{state.config.versionLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span>Cracked</span>
                  <span aria-hidden="true">·</span>
                  <span>O'zbek tili</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-xs text-[#9E9B93]">
                <span>Joriy vazifa</span>
                <span className="font-mono text-[#D1CEC5] tabular-nums">
                  {state.activeTask === "idle" ? "KUTISH" : state.activeTask.toUpperCase()}
                </span>
              </div>
              <p className="text-sm text-[#F5F4ED] font-medium">{state.taskDetail}</p>
              {state.targetCount && state.targetCount > 0 && (
                <p className="text-xs font-mono tabular-nums text-[#E59377]">
                  Maqsad jarayoni: {state.collectedCount} / {state.targetCount} ta
                </p>
              )}
              {state.activeTask === "speedrun" && (
                <p className="text-xs text-emerald-400">{state.speedrunStage}</p>
              )}
            </div>

            <div className="pt-3 border-t border-[#2C2B28] space-y-2.5">
              <div className="text-xs font-medium text-[#A6A39B]">Tezkor vazifa berish</div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {quickTasks.map((item) => {
                  const Icon = item.icon;
                  const active = state.activeTask === item.id;
                  return (
                    <motion.button
                      key={item.id}
                      type="button"
                      whileHover={{ y: -1.5 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => onSetTask(item.id, formConfig.followTarget)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-medium transition-colors whitespace-nowrap ${
                        active
                          ? "bg-[#D97757]/15 border-[#D97757]/70 text-[#F5F4ED]"
                          : "bg-[#141413] border-[#2C2B28] text-[#C5C2BA] hover:border-[#42403B] hover:text-[#F5F4ED]"
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5 shrink-0 text-[#D97757]" />
                      <span className="truncate">{item.label}</span>
                    </motion.button>
                  );
                })}
              </div>
            </div>
          </div>
        </motion.section>
      </div>

      {/* 4-Column Tabular Metrics Strip with staggered entrance */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((metric, idx) => {
          const Icon = metric.icon;
          const SecondaryIcon = metric.secondaryIcon;
          return (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.28, delay: 0.08 + idx * 0.045, ease: EASE }}
              whileHover={{ y: -2 }}
              className="bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl p-4 transition-colors hover:border-[#3E3C37]"
            >
              <div className="flex items-center justify-between text-xs text-[#9E9B93]">
                <span>{metric.label}</span>
                <Icon className="w-4 h-4 text-[#7C7971]" />
              </div>
              <div className="mt-2 flex items-baseline gap-3 font-mono tabular-nums">
                <span className="text-xl font-semibold text-[#F5F4ED] truncate">
                  {metric.primary}
                </span>
                {metric.secondary && (
                  <span className="text-xs text-[#9E9B93] inline-flex items-center gap-1 shrink-0">
                    {SecondaryIcon && <SecondaryIcon className="w-3 h-3" />}
                    {metric.secondary}
                  </span>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Live Bot & Server Activity Log Table */}
      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.32, delay: 0.18, ease: EASE }}
        className="bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl overflow-hidden"
      >
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#2C2B28]">
          <h3 className="text-sm font-semibold text-[#F5F4ED]">
            Jonli Server va Bot Hodisalari
          </h3>
          <span className="text-xs text-[#9E9B93] font-mono tabular-nums">
            {state.logs.length} ta yozuv
          </span>
        </div>
        <div className="max-h-72 overflow-y-auto divide-y divide-[#272623]">
          {state.logs.map((entry) => {
            const levelColor =
              entry.level === "error"
                ? "text-rose-400"
                : entry.level === "success"
                ? "text-emerald-400"
                : entry.level === "warn"
                ? "text-[#E59377]"
                : entry.level === "chat"
                ? "text-sky-300"
                : "text-[#D1CEC5]";

            return (
              <div
                key={entry.id}
                className="flex items-start gap-4 px-5 py-2.5 text-xs hover:bg-[#232220] transition-colors"
              >
                <span className="font-mono tabular-nums text-[#7C7971] shrink-0 pt-0.5">
                  {entry.timestamp}
                </span>
                <span className={`${levelColor} leading-relaxed`}>{entry.text}</span>
              </div>
            );
          })}
        </div>
      </motion.section>
    </div>
  );
}
