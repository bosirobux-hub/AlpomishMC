declare module "opusscript" {
  export default class OpusScript {
    static Application: {
      VOIP: number;
      AUDIO: number;
      RESTRICTED_LOWDELAY: number;
    };
    constructor(samplingRate?: number, channels?: number, application?: number);
    encode(buffer: Buffer, frameSize: number): Buffer;
    decode(buffer: Buffer): Buffer;
    delete(): void;
  }
}
