import { apiUrl } from "./api";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "motion/react";
import { Play, Square } from "lucide-react";
import { BotScreenPanel } from "./components/BotScreenPanel";
import { OverviewPanel } from "./components/OverviewPanel";
import { TasksPanel } from "./components/TasksPanel";
import { VoiceChatPanel } from "./components/VoiceChatPanel";
import { BotConfig, BotStateSnapshot, BotTaskMode, TtsProvider } from "./types";

type TabId = "overview" | "screen" | "voice" | "tasks";

const DEFAULT_CONFIG: BotConfig = {
  serverLink: "scrubbed-bust.eu.e4mc.link",
  username: "Alpomish_AI",
  versionLabel: "1.21.11 fabric",
  followTarget: "",
  launcherType: "tlauncher",
  authPassword: "",
  autoReconnect247: true,
  relayAiToGameChat: true,
  respondToGameChat: true,
  respondOnlyWhenAddressed: true,
  readGameChatAloud: true,
  useSimpleVoiceChat: true,
  aiProvider: "gemini",
  aiModel: "gemini-4-hydrogen",
  ttsProvider: "gemini",
  voiceName: "Charon",
};

const INITIAL_STATE: BotStateSnapshot = {
  status: "offline",
  statusMessage: "Bot hozircha ulanmagan.",
  config: DEFAULT_CONFIG,
  activeTask: "idle",
  taskDetail: "Kutish holatida",
  targetCount: null,
  collectedCount: 0,
  health: 20,
  food: 20,
  position: null,
  dimension: "overworld",
  nearbyPlayers: [],
  inventory: [],
  uptimeSeconds: 0,
  reconnectCount: 0,
  speedrunStage: "Tayyor",
  blocksMinedCount: 0,
  simpleVoiceChatStatus: "inactive",
  simpleVoiceChatMessage: "Simple Voice Chat ulanmagan",
  logs: [],
  inGameChat: [],
};

const EDITORIAL_EASE = [0.22, 1, 0.36, 1] as const;

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [botState, setBotState] = useState<BotStateSnapshot>(INITIAL_STATE);
  const [formConfig, setFormConfig] = useState<BotConfig>(DEFAULT_CONFIG);
  const configDirtyRef = useRef(false);
  const seenChatIdsRef = useRef<Set<string>>(new Set());
  const chatAudioRef = useRef<HTMLAudioElement | null>(null);
  const [isBusy, setIsBusy] = useState(false);

  useEffect(() => {
    const evt = new EventSource(apiUrl("/api/bot/events"));
    evt.onmessage = (event) => {
      try {
        const snapshot = JSON.parse(event.data) as BotStateSnapshot;
        setBotState(snapshot);
        if (!configDirtyRef.current) {
          setFormConfig(snapshot.config);
        }
      } catch {
        // ignore malformed frame
      }
    };
    return () => {
      evt.close();
    };
  }, []);

  // Automatically read incoming Minecraft player/bot chat aloud when enabled
  useEffect(() => {
    const items = botState.inGameChat || [];
    if (seenChatIdsRef.current.size === 0 && items.length > 0) {
      items.forEach((m) => seenChatIdsRef.current.add(m.id));
      return;
    }
    const newOnes = items.filter((m) => !seenChatIdsRef.current.has(m.id));
    if (newOnes.length === 0) return;
    newOnes.forEach((m) => seenChatIdsRef.current.add(m.id));

    if (!formConfig.readGameChatAloud) return;
    const latest = newOnes[newOnes.length - 1];
    if (latest.isSystem) return;

    const spokenText = latest.isBot
      ? latest.message
      : `${latest.sender} yozdi: ${latest.message}`;

    void (async () => {
      if (formConfig.ttsProvider === "gemini") {
        try {
          const res = await fetch(apiUrl("/api/ai/tts"), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: spokenText }),
          });
          if (res.ok) {
            const data = (await res.json()) as {
              audioBase64?: string;
              audioMimeType?: string;
            };
            if (data.audioBase64) {
              if (chatAudioRef.current) {
                chatAudioRef.current.pause();
              }
              const audio = new Audio(
                `data:${data.audioMimeType || "audio/wav"};base64,${data.audioBase64}`
              );
              chatAudioRef.current = audio;
              void audio.play();
              return;
            }
          }
        } catch {
          // Fall through to browser speechSynthesis
        }
      }
      if ("speechSynthesis" in window) {
        try {
          const u = new SpeechSynthesisUtterance(spokenText);
          u.lang = "uz-UZ";
          window.speechSynthesis.speak(u);
        } catch {
          // ignore
        }
      }
    })();
  }, [botState.inGameChat, formConfig.readGameChatAloud, formConfig.ttsProvider]);

  function handleChangeConfig(partial: Partial<BotConfig>) {
    configDirtyRef.current = true;
    setFormConfig((prev) => ({ ...prev, ...partial }));
  }

  function persistPartialConfig(partial: Partial<BotConfig>) {
    handleChangeConfig(partial);
    void fetch(apiUrl("/api/bot/config"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(partial),
    });
  }

  async function handleSaveConfig() {
    setIsBusy(true);
    try {
      const res = await fetch(apiUrl("/api/bot/config"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formConfig),
      });
      if (res.ok) {
        const data = await res.json();
        setBotState(data.state);
        setFormConfig(data.config);
        configDirtyRef.current = false;
      }
    } finally {
      setIsBusy(false);
    }
  }

  async function handleConnect() {
    setIsBusy(true);
    try {
      const res = await fetch(apiUrl("/api/bot/connect"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formConfig),
      });
      if (res.ok) {
        const snapshot = (await res.json()) as BotStateSnapshot;
        setBotState(snapshot);
        configDirtyRef.current = false;
      }
    } finally {
      setIsBusy(false);
    }
  }

  async function handleDisconnect() {
    setIsBusy(true);
    try {
      const res = await fetch(apiUrl("/api/bot/disconnect"), { method: "POST" });
      if (res.ok) {
        const snapshot = (await res.json()) as BotStateSnapshot;
        setBotState(snapshot);
      }
    } finally {
      setIsBusy(false);
    }
  }

  async function handleSetTask(
    task: BotTaskMode,
    targetPlayer?: string,
    targetCount?: number | null
  ) {
    const res = await fetch(apiUrl("/api/bot/task"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task, targetPlayer, targetCount }),
    });
    if (res.ok) {
      const snapshot = (await res.json()) as BotStateSnapshot;
      setBotState(snapshot);
    }
  }

  async function handleCancelTask() {
    const res = await fetch(apiUrl("/api/bot/cancel"), { method: "POST" });
    if (res.ok) {
      const snapshot = (await res.json()) as BotStateSnapshot;
      setBotState(snapshot);
    }
  }

  async function handleSendGameChat(message: string) {
    await fetch(apiUrl("/api/bot/say"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
  }

  const isConnectedOrTrying =
    botState.status === "online" ||
    botState.status === "connecting" ||
    botState.status === "reconnecting";

  const navItems: Array<{ id: TabId; label: string }> = [
    { id: "overview", label: "Boshqaruv" },
    { id: "screen", label: "Ekran va Inventar" },
    { id: "voice", label: "Ovoz va Suhbat" },
    { id: "tasks", label: "Vazifalar" },
  ];

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[#141413] text-[#F5F4ED] flex flex-col relative overflow-x-clip">
        {/* Subtle warm ambient radiance */}
        <div
          aria-hidden="true"
          className="pointer-events-none fixed inset-x-0 top-0 h-80 bg-[radial-gradient(ellipse_65%_55%_at_50%_-15%,rgba(217,119,87,0.12),transparent)]"
        />

        {/* Strict 3-Zone Top Bar Contract */}
        <header className="border-b border-[#2C2B28] bg-[#141413]/90 backdrop-blur-md sticky top-0 z-30">
          <div className="max-w-[1360px] mx-auto px-6 py-3.5 flex items-center justify-between gap-8">
            <motion.button
              type="button"
              whileHover={{ opacity: 0.9 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab("overview")}
              className="font-editorial text-xl font-semibold tracking-tight text-[#F5F4ED] whitespace-nowrap shrink-0"
            >
              Alpomish MC
            </motion.button>

            <nav className="flex items-center gap-2 sm:gap-3 overflow-x-auto p-1 rounded-xl bg-[#1C1B1A] border border-[#2C2B28]">
              {navItems.map((item) => {
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`relative px-3.5 py-1.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                      active ? "text-[#F5F4ED]" : "text-[#A6A39B] hover:text-[#F5F4ED]"
                    }`}
                  >
                    {active && (
                      <motion.span
                        layoutId="activeNavPill"
                        transition={{ type: "spring", stiffness: 420, damping: 34 }}
                        className="absolute inset-0 rounded-lg bg-[#2A2926] border border-[#3E3C37] shadow-sm"
                      />
                    )}
                    <span className="relative z-10">{item.label}</span>
                  </button>
                );
              })}
            </nav>

            <div className="shrink-0">
              {isConnectedOrTrying ? (
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  disabled={isBusy}
                  onClick={() => void handleDisconnect()}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
                >
                  <Square className="w-3.5 h-3.5" />
                  <span>Botni Uzish</span>
                </motion.button>
              ) : (
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  disabled={isBusy}
                  onClick={() => void handleConnect()}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#141413] bg-[#D97757] hover:bg-[#E38567] rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Botni Ulash</span>
                </motion.button>
              )}
            </div>
          </div>
        </header>

        {/* Main Content with fluid AnimatePresence tab transitions */}
        <main className="relative z-10 flex-1 max-w-[1360px] w-full mx-auto px-6 py-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.24, ease: EDITORIAL_EASE }}
            >
              {activeTab === "overview" && (
                <OverviewPanel
                  state={botState}
                  formConfig={formConfig}
                  onChangeConfig={handleChangeConfig}
                  onSaveConfig={handleSaveConfig}
                  onConnect={handleConnect}
                  onDisconnect={handleDisconnect}
                  onSetTask={handleSetTask}
                  isBusy={isBusy}
                />
              )}

              {activeTab === "screen" && <BotScreenPanel botState={botState} />}

              {activeTab === "voice" && (
                <VoiceChatPanel
                  botUsername={formConfig.username}
                  voiceName={formConfig.voiceName}
                  onChangeVoice={(voiceName) => persistPartialConfig({ voiceName })}
                  ttsProvider={formConfig.ttsProvider}
                  onChangeTtsProvider={(ttsProvider: TtsProvider) =>
                    persistPartialConfig({ ttsProvider })
                  }
                  relayToGame={formConfig.relayAiToGameChat}
                  onToggleRelay={() =>
                    persistPartialConfig({
                      relayAiToGameChat: !formConfig.relayAiToGameChat,
                    })
                  }
                  respondToGameChat={formConfig.respondToGameChat}
                  onToggleRespondGameChat={() =>
                    persistPartialConfig({
                      respondToGameChat: !formConfig.respondToGameChat,
                    })
                  }
                  respondOnlyWhenAddressed={formConfig.respondOnlyWhenAddressed}
                  onToggleRespondOnlyWhenAddressed={() =>
                    persistPartialConfig({
                      respondOnlyWhenAddressed: !formConfig.respondOnlyWhenAddressed,
                    })
                  }
                  readGameChatAloud={formConfig.readGameChatAloud}
                  onToggleReadGameChatAloud={() =>
                    persistPartialConfig({
                      readGameChatAloud: !formConfig.readGameChatAloud,
                    })
                  }
                  useSimpleVoiceChat={formConfig.useSimpleVoiceChat}
                  onToggleSimpleVoiceChat={() =>
                    persistPartialConfig({
                      useSimpleVoiceChat: !formConfig.useSimpleVoiceChat,
                    })
                  }
                  simpleVoiceChatStatus={botState.simpleVoiceChatStatus}
                  simpleVoiceChatMessage={botState.simpleVoiceChatMessage}
                  inGameChat={botState.inGameChat || []}
                  botStatus={botState.statusMessage}
                />
              )}

              {activeTab === "tasks" && (
                <TasksPanel
                  state={botState}
                  onSetTask={handleSetTask}
                  onCancelTask={handleCancelTask}
                  onSendGameChat={handleSendGameChat}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Clean Quiet Footer */}
        <footer className="border-t border-[#2C2B28] py-4 px-6 relative z-10">
          <div className="max-w-[1360px] mx-auto flex flex-wrap items-center justify-between gap-4 text-xs text-[#87847C]">
            <span>Alpomish MC · Yagona til: O'zbek tili</span>
            <span>1.21.11 Fabric · Cracked (Offline) · Simple Voice Chat</span>
          </div>
        </footer>
      </div>
    </MotionConfig>
  );
}
