import { apiUrl } from "../api";
import { useEffect, useRef, useState } from "react";
import { motion } from "motion/react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Backpack,
  Compass,
  Eye,
  Heart,
  MapPin,
  Shield,
  Utensils,
} from "lucide-react";
import { BotInventorySlot, BotStateSnapshot, BotViewSnapshot } from "../types";

interface BotScreenPanelProps {
  botState: BotStateSnapshot;
}

const EASE = [0.22, 1, 0.36, 1] as const;

const BLOCK_COLORS: Record<string, { top: string; side: string }> = {
  grass_block: { top: "#4f9d45", side: "#745438" },
  short_grass: { top: "#57a84a", side: "#488e3d" },
  dirt: { top: "#7c583b", side: "#6b4a30" },
  coarse_dirt: { top: "#6f4e34", side: "#5e412b" },
  podzol: { top: "#6a4c2f", side: "#5b4027" },
  stone: { top: "#7d8287", side: "#686d72" },
  cobblestone: { top: "#71767c", side: "#5c6066" },
  deepslate: { top: "#4b4f58", side: "#3b3f47" },
  sand: { top: "#d8cb97", side: "#c4b681" },
  gravel: { top: "#86817f", side: "#706b69" },
  water: { top: "rgba(44, 108, 212, 0.72)", side: "rgba(33, 86, 178, 0.72)" },
  oak_log: { top: "#9e7c52", side: "#5b4328" },
  birch_log: { top: "#b5a078", side: "#d9d8d2" },
  spruce_log: { top: "#6e4e2e", side: "#3c2917" },
  dark_oak_log: { top: "#4a3621", side: "#322313" },
  acacia_log: { top: "#9a5d3b", side: "#5c574f" },
  jungle_log: { top: "#8b6944", side: "#4e3f27" },
  cherry_log: { top: "#ba7989", side: "#3e2b33" },
  oak_leaves: { top: "#3b7d31", side: "#2d6425" },
  birch_leaves: { top: "#538a42", side: "#417033" },
  spruce_leaves: { top: "#2e5c36", side: "#224628" },
  cherry_leaves: { top: "#e59cb6", side: "#cf819d" },
  oak_planks: { top: "#a6824d", side: "#8f6d3e" },
  crafting_table: { top: "#b88a50", side: "#7e5531" },
  furnace: { top: "#7a7d82", side: "#56595e" },
  coal_ore: { top: "#5e6268", side: "#43464b" },
  iron_ore: { top: "#8b8580", side: "#736c66" },
  diamond_ore: { top: "#59c4d6", side: "#4c7279" },
  gold_ore: { top: "#d5b146", side: "#7e785a" },
  snow: { top: "#eef4f8", side: "#dbe4ec" },
  snow_block: { top: "#edf3f7", side: "#d7e0ea" },
  netherrack: { top: "#6d3232", side: "#572626" },
  end_stone: { top: "#dbda9a", side: "#c4c283" },
  torch: { top: "#ffca47", side: "#9c6d38" },
};

function getBlockPalette(name: string): { top: string; side: string } {
  if (BLOCK_COLORS[name]) return BLOCK_COLORS[name];
  if (name.includes("leaves")) return { top: "#3a7a30", side: "#2c6124" };
  if (name.includes("log") || name.includes("wood")) return { top: "#8c6b42", side: "#594127" };
  if (name.includes("planks")) return { top: "#a6824d", side: "#8b693b" };
  if (name.includes("diamond")) return { top: "#48cde0", side: "#3f7d87" };
  if (name.includes("iron")) return { top: "#9e9086", side: "#756d67" };
  if (name.includes("coal")) return { top: "#54585e", side: "#383b40" };
  if (name.includes("flower") || name.includes("poppy") || name.includes("rose")) {
    return { top: "#e05252", side: "#4c8f3b" };
  }
  return { top: "#7d8590", side: "#626973" };
}

function getFacingLabel(yaw: number): string {
  const norm = ((yaw % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
  if (norm < Math.PI / 4 || norm >= (7 * Math.PI) / 4) return "Shimol (-Z)";
  if (norm < (3 * Math.PI) / 4) return "G'arb (-X)";
  if (norm < (5 * Math.PI) / 4) return "Janub (+Z)";
  return "Sharq (+X)";
}

function formatItemShort(name: string): string {
  return name.replace(/_/g, " ");
}

function getItemBadgeColor(name: string): string {
  if (name.includes("diamond")) return "border-cyan-500/60 bg-cyan-950/35 text-cyan-200";
  if (name.includes("iron")) return "border-[#63605A] bg-[#292825] text-[#F5F4ED]";
  if (name.includes("gold")) return "border-amber-400/60 bg-amber-950/35 text-amber-200";
  if (name.includes("log") || name.includes("planks") || name.includes("wooden")) {
    return "border-[#91623D]/70 bg-[#2D2118] text-[#F5E6D3]";
  }
  if (name.includes("stone") || name.includes("cobble")) {
    return "border-[#4A4843] bg-[#232220] text-[#E5E3DC]";
  }
  if (name.includes("sword") || name.includes("axe") || name.includes("pickaxe")) {
    return "border-[#D97757]/60 bg-[#D97757]/12 text-[#F5F4ED]";
  }
  return "border-[#33312D] bg-[#141413] text-[#D1CEC5]";
}

function renderFirstPersonCanvas(canvas: HTMLCanvasElement, view: BotViewSnapshot) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  if (!view.online || !view.position) {
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, "#141413");
    grad.addColorStop(1, "#1D1B19");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = "rgba(217, 119, 87, 0.08)";
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    ctx.fillStyle = "#F5F4ED";
    ctx.font = "600 19px Georgia, serif";
    ctx.textAlign = "center";
    ctx.fillText("Bot ekrani hozircha o'chiq", w / 2, h / 2 - 10);
    ctx.fillStyle = "#A6A39B";
    ctx.font = "13px system-ui, sans-serif";
    ctx.fillText(
      "Bot serverga ulangach uning ko'rayotgan 3D dunyosi shu yerda jonli ko'rinadi",
      w / 2,
      h / 2 + 18
    );
    return;
  }

  const tod = ((view.timeOfDay % 24000) + 24000) % 24000;
  const isNether = view.dimension.includes("nether");
  const isEnd = view.dimension.includes("end");
  const skyGrad = ctx.createLinearGradient(0, 0, 0, h);
  if (isNether) {
    skyGrad.addColorStop(0, "#310d0d");
    skyGrad.addColorStop(1, "#5c1b12");
  } else if (isEnd) {
    skyGrad.addColorStop(0, "#0d0914");
    skyGrad.addColorStop(1, "#201730");
  } else if (tod > 13000 && tod < 23000) {
    skyGrad.addColorStop(0, "#090f24");
    skyGrad.addColorStop(1, "#16233f");
  } else if ((tod >= 12000 && tod <= 13500) || tod >= 22800) {
    skyGrad.addColorStop(0, "#3b2c4e");
    skyGrad.addColorStop(1, "#d97b4c");
  } else {
    skyGrad.addColorStop(0, "#4c8be0");
    skyGrad.addColorStop(1, "#9bc7f7");
  }
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, w, h);

  const eyeX = view.position.x;
  const eyeY = view.position.y + 1.62;
  const eyeZ = view.position.z;

  const yaw = view.yaw;
  const pitch = view.pitch;

  const fx = -Math.sin(yaw) * Math.cos(pitch);
  const fy = Math.sin(pitch);
  const fz = -Math.cos(yaw) * Math.cos(pitch);

  const rx = Math.cos(yaw);
  const rz = -Math.sin(yaw);

  const ux = Math.sin(yaw) * Math.sin(pitch);
  const uy = Math.cos(pitch);
  const uz = Math.cos(yaw) * Math.sin(pitch);

  const focal = w * 0.68;
  const cx = w / 2;
  const cy = h / 2;

  function projectPoint(px: number, py: number, pz: number) {
    const dx = px - eyeX;
    const dy = py - eyeY;
    const dz = pz - eyeZ;
    const camZ = dx * fx + dy * fy + dz * fz;
    if (camZ <= 0.15) return null;
    const camX = dx * rx + dz * rz;
    const camY = dx * ux + dy * uy + dz * uz;
    return {
      x: cx + (camX / camZ) * focal,
      y: cy - (camY / camZ) * focal,
      z: camZ,
    };
  }

  const sortedBlocks = [...view.blocks]
    .map((b) => {
      const dx = b.x + 0.5 - eyeX;
      const dy = b.y + 0.5 - eyeY;
      const dz = b.z + 0.5 - eyeZ;
      return {
        b,
        distSq: dx * dx + dy * dy + dz * dz,
        camZ: dx * fx + dy * fy + dz * fz,
      };
    })
    .filter((item) => item.camZ > -1.2 && item.distSq <= 105)
    .sort((a, b) => b.distSq - a.distSq);

  const CUBE_VERTS: Array<[number, number, number]> = [
    [0, 0, 0],
    [1, 0, 0],
    [1, 1, 0],
    [0, 1, 0],
    [0, 0, 1],
    [1, 0, 1],
    [1, 1, 1],
    [0, 1, 1],
  ];

  const FACES: Array<{
    indices: [number, number, number, number];
    normal: [number, number, number];
    isTop?: boolean;
    shade: number;
  }> = [
    { indices: [3, 2, 6, 7], normal: [0, 1, 0], isTop: true, shade: 1.0 },
    { indices: [0, 1, 5, 4], normal: [0, -1, 0], shade: 0.55 },
    { indices: [1, 2, 6, 5], normal: [1, 0, 0], shade: 0.85 },
    { indices: [0, 4, 7, 3], normal: [-1, 0, 0], shade: 0.72 },
    { indices: [4, 5, 6, 7], normal: [0, 0, 1], shade: 0.9 },
    { indices: [0, 3, 2, 1], normal: [0, 0, -1], shade: 0.76 },
  ];

  for (const { b } of sortedBlocks) {
    const palette = getBlockPalette(b.name);
    const projectedVerts = CUBE_VERTS.map(([vx, vy, vz]) =>
      projectPoint(b.x + vx, b.y + vy, b.z + vz)
    );

    for (const face of FACES) {
      const fcx = b.x + 0.5 + face.normal[0] * 0.5;
      const fcy = b.y + 0.5 + face.normal[1] * 0.5;
      const fcz = b.z + 0.5 + face.normal[2] * 0.5;
      const dotToEye =
        (eyeX - fcx) * face.normal[0] +
        (eyeY - fcy) * face.normal[1] +
        (eyeZ - fcz) * face.normal[2];
      if (dotToEye <= 0) continue;

      const pts = face.indices.map((idx) => projectedVerts[idx]);
      if (pts.some((p) => !p)) continue;

      const p0 = pts[0]!;
      const p1 = pts[1]!;
      const p2 = pts[2]!;
      const p3 = pts[3]!;

      if (
        Math.max(p0.x, p1.x, p2.x, p3.x) < -40 ||
        Math.min(p0.x, p1.x, p2.x, p3.x) > w + 40 ||
        Math.max(p0.y, p1.y, p2.y, p3.y) < -40 ||
        Math.min(p0.y, p1.y, p2.y, p3.y) > h + 40
      ) {
        continue;
      }

      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.lineTo(p3.x, p3.y);
      ctx.closePath();

      ctx.fillStyle = face.isTop ? palette.top : palette.side;
      ctx.fill();

      if (face.shade < 0.98) {
        ctx.fillStyle = `rgba(0, 0, 0, ${(1 - face.shade).toFixed(2)})`;
        ctx.fill();
      }

      ctx.strokeStyle = "rgba(20, 20, 19, 0.28)";
      ctx.lineWidth = 0.8;
      ctx.stroke();
    }
  }

  const sortedEntities = [...view.entities].sort((a, b) => b.distance - a.distance);
  for (const ent of sortedEntities) {
    const base = projectPoint(ent.x, ent.y, ent.z);
    const head = projectPoint(ent.x, ent.y + (ent.kind === "item" ? 0.5 : 1.85), ent.z);
    if (!base || !head) continue;

    const entH = Math.max(12, Math.abs(base.y - head.y));
    const entW = Math.max(8, entH * 0.45);
    const color =
      ent.kind === "player"
        ? "#34d399"
        : ent.kind === "hostile"
        ? "#f87171"
        : ent.kind === "animal"
        ? "#D97757"
        : "#60a5fa";

    ctx.fillStyle = color;
    ctx.fillRect(base.x - entW / 2, head.y, entW, entH);
    ctx.strokeStyle = "#141413";
    ctx.lineWidth = 1.5;
    ctx.strokeRect(base.x - entW / 2, head.y, entW, entH);

    const label = `${ent.name} (${ent.distance}m)`;
    ctx.font = "600 11px system-ui, sans-serif";
    const textW = ctx.measureText(label).width;
    ctx.fillStyle = "rgba(20, 20, 19, 0.82)";
    ctx.fillRect(base.x - textW / 2 - 5, head.y - 20, textW + 10, 16);
    ctx.fillStyle = "#F5F4ED";
    ctx.textAlign = "center";
    ctx.fillText(label, base.x, head.y - 8);
  }

  ctx.strokeStyle = "rgba(245, 244, 237, 0.88)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(cx - 8, cy);
  ctx.lineTo(cx + 8, cy);
  ctx.moveTo(cx, cy - 8);
  ctx.lineTo(cx, cy + 8);
  ctx.stroke();

  const slotMap = new Map<number, BotInventorySlot>();
  for (const s of view.slots) {
    slotMap.set(s.slot, s);
  }
  const barW = 9 * 42;
  const barX = (w - barW) / 2;
  const barY = h - 52;
  ctx.fillStyle = "rgba(20, 20, 19, 0.82)";
  ctx.fillRect(barX - 4, barY - 4, barW + 8, 44);
  for (let i = 0; i < 9; i += 1) {
    const sx = barX + i * 42;
    const isHeld = view.heldSlot === i;
    ctx.strokeStyle = isHeld ? "#D97757" : "#4A4843";
    ctx.lineWidth = isHeld ? 2.5 : 1;
    ctx.strokeRect(sx + 1, barY, 38, 36);
    const item = slotMap.get(36 + i);
    if (item) {
      ctx.fillStyle = "#F5F4ED";
      ctx.font = "600 9px monospace";
      ctx.textAlign = "center";
      ctx.fillText(item.name.slice(0, 6), sx + 20, barY + 18);
      if (item.count > 1) {
        ctx.fillStyle = "#D97757";
        ctx.font = "700 10px monospace";
        ctx.textAlign = "right";
        ctx.fillText(String(item.count), sx + 36, barY + 32);
      }
    }
  }
}

function renderRadarCanvas(canvas: HTMLCanvasElement, view: BotViewSnapshot) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const size = canvas.width;
  const center = size / 2;
  ctx.clearRect(0, 0, size, size);

  ctx.fillStyle = "#121211";
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = "rgba(245, 244, 237, 0.08)";
  ctx.lineWidth = 1;
  [45, 90, 130].forEach((r) => {
    ctx.beginPath();
    ctx.arc(center, center, r, 0, Math.PI * 2);
    ctx.stroke();
  });

  if (!view.online || !view.position) {
    ctx.fillStyle = "#7C7971";
    ctx.font = "12px system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("Xarita kutilmoqda", center, center);
    return;
  }

  const scale = 8;
  const bx = view.position.x;
  const bz = view.position.z;

  const topBlocks = new Map<string, { y: number; name: string }>();
  for (const b of view.blocks) {
    const key = `${b.x},${b.z}`;
    const prev = topBlocks.get(key);
    if (!prev || b.y > prev.y) {
      topBlocks.set(key, { y: b.y, name: b.name });
    }
  }
  for (const [key, val] of topBlocks) {
    const [wxStr, wzStr] = key.split(",");
    const wx = Number(wxStr);
    const wz = Number(wzStr);
    const rx = center + (wx - bx) * scale;
    const ry = center + (wz - bz) * scale;
    ctx.fillStyle = getBlockPalette(val.name).top;
    ctx.globalAlpha = 0.55;
    ctx.fillRect(rx - scale / 2, ry - scale / 2, scale - 1, scale - 1);
  }
  ctx.globalAlpha = 1;

  for (const ent of view.entities) {
    const ex = center + (ent.x - bx) * scale;
    const ez = center + (ent.z - bz) * scale;
    if (ex < 6 || ex > size - 6 || ez < 6 || ez > size - 6) continue;
    ctx.fillStyle =
      ent.kind === "player"
        ? "#34d399"
        : ent.kind === "hostile"
        ? "#f43f5e"
        : ent.kind === "animal"
        ? "#D97757"
        : "#60a5fa";
    ctx.beginPath();
    ctx.arc(ex, ez, 4.5, 0, Math.PI * 2);
    ctx.fill();
  }

  const lookAngleX = -Math.sin(view.yaw);
  const lookAngleZ = -Math.cos(view.yaw);
  const angle = Math.atan2(lookAngleZ, lookAngleX);

  ctx.fillStyle = "rgba(217, 119, 87, 0.24)";
  ctx.beginPath();
  ctx.moveTo(center, center);
  ctx.arc(center, center, 44, angle - 0.55, angle + 0.55);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#D97757";
  ctx.beginPath();
  ctx.arc(center, center, 5.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#F5F4ED";
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

export function BotScreenPanel({ botState }: BotScreenPanelProps) {
  const [view, setView] = useState<BotViewSnapshot>({
    online: false,
    username: botState.config.username,
    status: botState.status,
    statusMessage: botState.statusMessage,
    position: botState.position,
    yaw: 0,
    pitch: 0,
    dimension: botState.dimension,
    biome: "noma'lum",
    timeOfDay: 6000,
    health: botState.health,
    food: botState.food,
    heldSlot: 0,
    slots: [],
    blocks: [],
    entities: [],
  });

  const povCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const radarCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    let inFlight = false;

    const poll = async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const res = await fetch(apiUrl("/api/bot/view"));
        if (res.ok && !cancelled) {
          const data = (await res.json()) as BotViewSnapshot;
          setView(data);
        }
      } catch {
        // ignore polling blip
      } finally {
        inFlight = false;
      }
    };

    void poll();
    const timer = setInterval(() => void poll(), 480);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    if (povCanvasRef.current) {
      renderFirstPersonCanvas(povCanvasRef.current, view);
    }
    if (radarCanvasRef.current) {
      renderRadarCanvas(radarCanvasRef.current, view);
    }
  }, [view]);

  async function nudgeLook(yawDelta: number, pitchDelta: number) {
    try {
      const res = await fetch(apiUrl("/api/bot/look"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ yawDelta, pitchDelta }),
      });
      if (res.ok) {
        const data = (await res.json()) as BotViewSnapshot;
        setView(data);
      }
    } catch {
      // ignore
    }
  }

  const slotMap = new Map<number, BotInventorySlot>();
  for (const s of view.slots) {
    slotMap.set(s.slot, s);
  }

  const armorSlots: Array<{ slot: number; label: string }> = [
    { slot: 5, label: "Dubulg'a" },
    { slot: 6, label: "Ko'krak" },
    { slot: 7, label: "Shim" },
    { slot: 8, label: "Etik" },
    { slot: 45, label: "Chap qo'l" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <motion.section
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: EASE }}
          className="lg:col-span-8 bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl overflow-hidden flex flex-col"
        >
          <div className="px-5 py-3.5 border-b border-[#2C2B28] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Eye className="w-4 h-4 text-[#D97757]" />
              <h2 className="text-base font-medium text-[#F5F4ED]">
                Botning Jonli Ekrani (1-shaxs ko'rinishi)
              </h2>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono tabular-nums text-[#A6A39B]">
              <span className="inline-flex items-center gap-1 text-rose-300">
                <Heart className="w-3.5 h-3.5" /> {view.health}/20
              </span>
              <span className="inline-flex items-center gap-1 text-[#E59377]">
                <Utensils className="w-3.5 h-3.5" /> {view.food}/20
              </span>
              <span>{view.blocks.length} blok ko'rinmoqda</span>
            </div>
          </div>

          <div className="relative bg-[#121211]">
            <canvas
              ref={povCanvasRef}
              width={800}
              height={450}
              className="w-full aspect-video block"
            />
            {view.online && view.position && (
              <div className="absolute top-3 left-3 px-3 py-1.5 rounded-xl bg-[#141413]/85 border border-[#32302C] text-xs font-mono tabular-nums text-[#F5F4ED] space-y-0.5">
                <div>
                  XYZ: {view.position.x} / {view.position.y} / {view.position.z}
                </div>
                <div className="text-[#A6A39B]">
                  Bioma: {view.biome} · {getFacingLabel(view.yaw)}
                </div>
              </div>
            )}
          </div>

          <div className="px-5 py-3 border-t border-[#2C2B28] flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs text-[#A6A39B]">
              Kamerani burish (o'yin ichida botning boshini aylantiradi):
            </span>
            <div className="flex items-center gap-2">
              {[
                { label: "Chapga", icon: ArrowLeft, yaw: 0.45, pitch: 0 },
                { label: "Tepaga", icon: ArrowUp, yaw: 0, pitch: 0.28 },
                { label: "Pastga", icon: ArrowDown, yaw: 0, pitch: -0.28 },
                { label: "O'ngga", icon: ArrowRight, yaw: -0.45, pitch: 0 },
              ].map((btn) => {
                const Icon = btn.icon;
                return (
                  <motion.button
                    key={btn.label}
                    type="button"
                    whileTap={{ scale: 0.95 }}
                    disabled={!view.online}
                    onClick={() => void nudgeLook(btn.yaw, btn.pitch)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#141413] border border-[#32302C] hover:border-[#D97757]/60 rounded-xl text-xs text-[#E5E3DC] disabled:opacity-40 transition-colors"
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{btn.label}</span>
                  </motion.button>
                );
              })}
            </div>
          </div>
        </motion.section>

        {/* Right: Location & 2D Top-Down Radar */}
        <motion.section
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.34, delay: 0.06, ease: EASE }}
          className="lg:col-span-4 bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl p-5 flex flex-col justify-between space-y-4"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-[#2C2B28] pb-3">
              <h3 className="text-sm font-semibold text-[#F5F4ED] inline-flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#D97757]" />
                <span>Qayerdaligi (Joylashuv)</span>
              </h3>
              <span className="text-xs font-mono text-[#9E9B93]">{view.dimension}</span>
            </div>

            <div className="grid grid-cols-3 gap-2 font-mono tabular-nums text-center">
              {[
                { label: "X", val: view.position ? view.position.x : "—" },
                { label: "Y", val: view.position ? view.position.y : "—" },
                { label: "Z", val: view.position ? view.position.z : "—" },
              ].map((coord) => (
                <div
                  key={coord.label}
                  className="bg-[#121211] border border-[#2C2B28] rounded-xl p-2.5"
                >
                  <div className="text-[11px] text-[#7C7971]">{coord.label}</div>
                  <div className="text-sm font-semibold text-[#F5F4ED]">{coord.val}</div>
                </div>
              ))}
            </div>

            <div className="flex justify-center">
              <canvas
                ref={radarCanvasRef}
                width={260}
                height={260}
                className="rounded-2xl border border-[#2C2B28] bg-[#121211]"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#A6A39B] px-1">
              <span className="inline-flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-[#D97757]" />
                <span>{getFacingLabel(view.yaw)}</span>
              </span>
              <span>Bioma: {view.biome}</span>
            </div>
          </div>

          <div className="pt-3 border-t border-[#2C2B28] space-y-2 text-xs">
            <div className="flex flex-wrap gap-3 text-[#9E9B93]">
              <span className="text-emerald-400">● O'yinchi</span>
              <span className="text-rose-400">● Dushman mob</span>
              <span className="text-[#D97757]">● Hayvon</span>
              <span className="text-sky-400">● Buyum</span>
            </div>
            <div className="text-[#9E9B93]">
              Simple Voice Chat:{" "}
              <span className="text-[#F5F4ED] font-medium">
                {botState.simpleVoiceChatMessage}
              </span>
            </div>
          </div>
        </motion.section>
      </div>

      {/* Bottom Full-Width Visual Inventory Grid */}
      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.34, delay: 0.1, ease: EASE }}
        className="bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl p-5 space-y-5"
      >
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#2C2B28] pb-3.5">
          <div className="flex items-center gap-2.5">
            <Backpack className="w-4 h-4 text-[#D97757]" />
            <h3 className="text-sm font-semibold text-[#F5F4ED]">
              Botning To'liq Inventari (Zirh, Qo'llar, 27 Asosiy va 9 Tezkor Katak)
            </h3>
          </div>
          <span className="text-xs font-mono tabular-nums text-[#9E9B93]">
            Band kataklar: {view.slots.length} / 41
          </span>
        </div>

        {/* Armor & Offhand row */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-[#A6A39B] inline-flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5" />
            <span>Zirh va Chap Qo'l</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            {armorSlots.map(({ slot, label }) => {
              const item = slotMap.get(slot);
              return (
                <div
                  key={slot}
                  className={`p-2.5 rounded-xl border min-h-[58px] flex flex-col justify-between transition-colors ${
                    item ? getItemBadgeColor(item.name) : "border-[#2C2B28] bg-[#141413] text-[#6E6B64]"
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-[#9E9B93]">{label}</span>
                    {item && (
                      <span className="font-mono font-semibold tabular-nums text-[#E59377]">
                        x{item.count}
                      </span>
                    )}
                  </div>
                  <div className="text-xs font-mono truncate mt-1">
                    {item ? formatItemShort(item.name) : "Bo'sh"}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 27 Main Inventory Slots */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-[#A6A39B]">Asosiy Ryukzak (27 ta katak)</div>
          <div className="grid grid-cols-3 sm:grid-cols-9 gap-2">
            {Array.from({ length: 27 }, (_, idx) => 9 + idx).map((slotNum) => {
              const item = slotMap.get(slotNum);
              return (
                <div
                  key={slotNum}
                  title={item ? `${item.displayName} (${item.count})` : `Katak #${slotNum}`}
                  className={`p-2 rounded-xl border min-h-[60px] flex flex-col justify-between transition-colors ${
                    item ? getItemBadgeColor(item.name) : "border-[#272623] bg-[#141413]/80 text-[#59564F]"
                  }`}
                >
                  <div className="text-[11px] font-mono leading-tight break-words line-clamp-2">
                    {item ? formatItemShort(item.name) : "·"}
                  </div>
                  {item && (
                    <div className="text-right text-[11px] font-mono font-semibold tabular-nums text-[#E59377]">
                      x{item.count}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* 9 Hotbar Slots */}
        <div className="space-y-2">
          <div className="text-xs font-medium text-[#A6A39B]">
            Qo'l Paneli (Hotbar · Terrakota hoshiya — hozir qo'lda turgan buyum)
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-9 gap-2">
            {Array.from({ length: 9 }, (_, idx) => {
              const slotNum = 36 + idx;
              const item = slotMap.get(slotNum);
              const isHeld = view.heldSlot === idx;
              return (
                <div
                  key={slotNum}
                  title={item ? `${item.displayName} (${item.count})` : `Hotbar #${idx + 1}`}
                  className={`p-2 rounded-xl border min-h-[64px] flex flex-col justify-between transition-colors ${
                    isHeld ? "ring-2 ring-[#D97757] " : ""
                  }${
                    item ? getItemBadgeColor(item.name) : "border-[#2C2B28] bg-[#141413] text-[#6E6B64]"
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#7C7971]">
                    <span>#{idx + 1}</span>
                    {isHeld && <span className="text-[#E59377] font-semibold">QO'LDA</span>}
                  </div>
                  <div className="text-[11px] font-mono leading-tight break-words line-clamp-2 mt-0.5">
                    {item ? formatItemShort(item.name) : "Bo'sh"}
                  </div>
                  {item && (
                    <div className="text-right text-[11px] font-mono font-semibold tabular-nums text-[#E59377]">
                      x{item.count}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </motion.section>
    </div>
  );
}
