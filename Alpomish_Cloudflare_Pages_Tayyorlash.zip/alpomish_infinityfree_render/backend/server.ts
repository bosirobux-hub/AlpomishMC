import "dotenv/config";
import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { botManager, isAddressedToBot } from "./server/botManager.js";
import {
  generateUzbekCompanionTurn,
  getProviderAvailability,
  synthesizeUzbekSpeech,
  transcribeUzbekAudio,
} from "./server/geminiService.js";
import { AiActionType, BotConfig, BotTaskMode } from "./server/types.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// Frontend InfinityFree subdomainidan API Render backendiga ulanadi.
const allowedOrigin = (process.env.FRONTEND_ORIGIN || "*").trim();
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (allowedOrigin === "*" || (origin && origin === allowedOrigin)) {
    res.setHeader("Access-Control-Allow-Origin", allowedOrigin === "*" ? "*" : origin!);
  }
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") { res.sendStatus(204); return; }
  next();
});
app.use(express.json({ limit: "15mb" }));
app.get("/health", (_req, res) => res.json({ ok: true, service: "alpomish-api" }));

function parseTargetCountFromText(text: string): number | undefined {
  const m =
    text.match(/\b(\d{1,4})\s*(?:ta|dona|blok|yog['’]?och|daraxt|tosh)?\b/i) ||
    text.match(/\b(\d{1,4})\b/);
  if (!m || !m[1]) return undefined;
  const n = Number.parseInt(m[1], 10);
  if (!Number.isFinite(n) || n <= 0) return undefined;
  return Math.min(2304, n);
}

function executeAiAction(
  action: AiActionType,
  targetPlayer?: string,
  inGameMessage?: string,
  targetCount?: number
) {
  const snapshot = botManager.getSnapshot();
  if (action === "chop_wood") {
    botManager.setTask("chop_wood", undefined, targetCount);
  } else if (action === "speedrun") {
    botManager.setTask("speedrun");
  } else if (action === "follow_player" || action === "come_here") {
    botManager.setTask("follow_player", targetPlayer);
  } else if (action === "mine_ores") {
    botManager.setTask("mine_ores", undefined, targetCount);
  } else if (action === "guard") {
    botManager.setTask("guard", targetPlayer);
  } else if (action === "hunt_food") {
    botManager.setTask("hunt_food");
  } else if (action === "collect_drops") {
    botManager.setTask("collect_drops");
  } else if (action === "farm_crops") {
    botManager.setTask("farm_crops");
  } else if (action === "fish") {
    botManager.setTask("fish");
  } else if (action === "torch_place") {
    botManager.setTask("torch_place");
  } else if (action === "sleep_bed") {
    botManager.setTask("sleep_bed");
  } else if (action === "build_pillar") {
    botManager.setTask("build_pillar");
  } else if (action === "stop_task") {
    botManager.cancelCurrentTask(false);
  }

  if (inGameMessage && snapshot.config.relayAiToGameChat) {
    botManager.sayInGame(inGameMessage);
  }
}

async function speakTextInGameVoice(text: string) {
  const cfg = botManager.getConfig();
  if (!cfg.useSimpleVoiceChat || !text.trim()) return;
  if (botManager.getSnapshot().simpleVoiceChatStatus !== "connected") return;
  try {
    const tts = await synthesizeUzbekSpeech(text, cfg.voiceName, "gemini");
    if (tts.audioBase64) {
      await botManager.speakInSimpleVoiceChat(tts.audioBase64);
    }
  } catch {
    // Simple Voice Chat fallback: ignore if TTS fails silently
  }
}

let lastAutoReplyAt = 0;
botManager.setInGameChatListener((sender, message, isSystem) => {
  const snapshot = botManager.getSnapshot();
  if (isSystem || !snapshot.config.respondToGameChat) return;

  // Do not treat unrelated chatter between players as addressed to the bot
  if (
    snapshot.config.respondOnlyWhenAddressed &&
    !isAddressedToBot(message, snapshot.config.username)
  ) {
    return;
  }

  const lower = message.toLowerCase();

  // Instant cancel fast-path (e.g. "almopish_ai bekor qilindi")
  if (
    lower.includes("bekor qil") ||
    lower.includes("otmena") ||
    lower.includes("to'xta") ||
    lower.includes("toxta")
  ) {
    botManager.cancelCurrentTask(true);
    void speakTextInGameVoice("Xo'p, aytilgan ish bekor qilindi.");
    return;
  }

  const now = Date.now();
  if (now - lastAutoReplyAt < 1400) return;
  lastAutoReplyAt = now;

  const fallbackCount = parseTargetCountFromText(message);

  void (async () => {
    try {
      const turn = await generateUzbekCompanionTurn(
        `${sender} Minecraft o'yin chatida botga murojaat qildi: "${message}"`,
        snapshot,
        []
      );
      const effectiveTarget = turn.targetPlayer || sender;
      const effectiveCount = turn.targetCount ?? fallbackCount;
      executeAiAction(
        turn.action,
        effectiveTarget,
        turn.inGameMessage || turn.replyUzbek,
        effectiveCount
      );
      if (turn.replyUzbek) {
        void speakTextInGameVoice(turn.replyUzbek);
      }
    } catch {
      if (lower.includes("daraxt") || lower.includes("yog'och") || lower.includes("yogoch")) {
        botManager.setTask("chop_wood", undefined, fallbackCount);
        const msg = fallbackCount
          ? `Xo'p, ${fallbackCount} ta daraxt yig'ishga ketdim!`
          : "Xo'p, daraxt chopishga ketdim!";
        botManager.sayInGame(msg);
        void speakTextInGameVoice(msg);
      } else if (lower.includes("speedrun")) {
        botManager.setTask("speedrun");
        botManager.sayInGame("Speedrun rejimini boshladim!");
      } else if (lower.includes("yur") || lower.includes("kel")) {
        botManager.setTask("follow_player", sender);
        botManager.sayInGame(`${sender}, orqangizdan yuryapman!`);
      } else if (lower.includes("qaz") || lower.includes("kon")) {
        botManager.setTask("mine_ores", undefined, fallbackCount);
        const msg = fallbackCount
          ? `Xo'p, ${fallbackCount} ta resurs qazishga kirishdim!`
          : "Kon qazishga kirishdim!";
        botManager.sayInGame(msg);
        void speakTextInGameVoice(msg);
      } else if (lower.includes("qoriq") || lower.includes("qo'riq")) {
        botManager.setTask("guard", sender);
        botManager.sayInGame(`${sender}, atrofni qo'riqlayapman!`);
      }
    }
  })();
});

// Bot state, screen view & SSE stream
app.get("/api/bot/state", (_req, res) => {
  res.json(botManager.getSnapshot());
});

app.get("/api/bot/view", (_req, res) => {
  res.json(botManager.getViewSnapshot());
});

app.post("/api/bot/look", (req, res) => {
  const { yawDelta = 0, pitchDelta = 0 } = req.body as {
    yawDelta?: number;
    pitchDelta?: number;
  };
  botManager.lookRelative(Number(yawDelta) || 0, Number(pitchDelta) || 0);
  res.json(botManager.getViewSnapshot());
});

app.get("/api/bot/events", (req, res) => {
  botManager.addSseClient(res);
  req.on("close", () => {
    res.end();
  });
});

app.post("/api/bot/config", (req, res) => {
  const updated = botManager.updateConfig(req.body as Partial<BotConfig>);
  res.json({ config: updated, state: botManager.getSnapshot() });
});

app.post("/api/bot/connect", (req, res) => {
  const state = botManager.connect(req.body as Partial<BotConfig>);
  res.json(state);
});

app.post("/api/bot/disconnect", (_req, res) => {
  const state = botManager.disconnect();
  res.json(state);
});

app.post("/api/bot/task", (req, res) => {
  const { task, targetPlayer, targetCount } = req.body as {
    task: BotTaskMode;
    targetPlayer?: string;
    targetCount?: number | null;
  };
  const state = botManager.setTask(task, targetPlayer, targetCount);
  res.json(state);
});

app.post("/api/bot/cancel", (_req, res) => {
  const state = botManager.cancelCurrentTask(true);
  void speakTextInGameVoice("Xo'p, aytilgan ish bekor qilindi.");
  res.json(state);
});

app.post("/api/bot/say", (req, res) => {
  const { message } = req.body as { message: string };
  const sent = botManager.sayInGame(message || "");
  res.json({ sent, state: botManager.getSnapshot() });
});

app.get("/api/ai/providers", (_req, res) => {
  res.json(getProviderAvailability());
});

// Uzbek AI Chat + Voice + Simple Voice Chat bridge
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, history = [], speak = true } = req.body as {
      message: string;
      history?: Array<{ role: "user" | "assistant"; text: string }>;
      speak?: boolean;
    };

    if (!message || !message.trim()) {
      res.status(400).json({ error: "Xabar bo'sh bo'lmasligi kerak." });
      return;
    }

    const clean = message.trim();
    const botState = botManager.getSnapshot();
    const lower = clean.toLowerCase();

    if (lower.includes("bekor qil") || lower.includes("bekor qilindi")) {
      const nextState = botManager.cancelCurrentTask(true);
      let audioBase64: string | undefined;
      let audioMimeType: string | undefined;
      if (speak && botState.config.ttsProvider === "gemini") {
        try {
          const tts = await synthesizeUzbekSpeech(
            "Xo'p, aytilgan ish bekor qilindi.",
            botState.config.voiceName,
            "gemini"
          );
          audioBase64 = tts.audioBase64;
          audioMimeType = tts.audioMimeType;
          if (audioBase64 && botState.config.useSimpleVoiceChat) {
            void botManager.speakInSimpleVoiceChat(audioBase64);
          }
        } catch {
          // ignore
        }
      }
      res.json({
        replyUzbek: "Xo'p, aytilgan ish bekor qilindi.",
        action: "stop_task",
        audioBase64,
        audioMimeType,
        state: nextState,
      });
      return;
    }

    const turn = await generateUzbekCompanionTurn(clean, botState, history);
    const parsedCount = turn.targetCount ?? parseTargetCountFromText(clean);

    executeAiAction(
      turn.action,
      turn.targetPlayer,
      turn.inGameMessage || (botState.config.relayAiToGameChat ? turn.replyUzbek : undefined),
      parsedCount
    );

    let audioBase64: string | undefined;
    let audioMimeType: string | undefined;
    let ttsError: string | undefined;

    if (speak) {
      if (botState.config.ttsProvider === "gemini") {
        try {
          const tts = await synthesizeUzbekSpeech(
            turn.replyUzbek,
            botState.config.voiceName,
            "gemini"
          );
          audioBase64 = tts.audioBase64;
          audioMimeType = tts.audioMimeType;
          if (audioBase64 && botState.config.useSimpleVoiceChat) {
            void botManager.speakInSimpleVoiceChat(audioBase64);
          }
        } catch (err) {
          ttsError = err instanceof Error ? err.message : String(err);
        }
      } else if (botState.config.useSimpleVoiceChat && botState.simpleVoiceChatStatus === "connected") {
        void speakTextInGameVoice(turn.replyUzbek);
      }
    }

    res.json({
      ...turn,
      targetCount: parsedCount,
      audioBase64,
      audioMimeType,
      ttsError,
      state: botManager.getSnapshot(),
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

app.post("/api/ai/voice-turn", async (req, res) => {
  try {
    const { audioBase64: inputAudio, mimeType, history = [], speak = true } = req.body as {
      audioBase64: string;
      mimeType: string;
      history?: Array<{ role: "user" | "assistant"; text: string }>;
      speak?: boolean;
    };

    if (!inputAudio) {
      res.status(400).json({ error: "Audio ma'lumot yuborilmadi." });
      return;
    }

    const transcript = await transcribeUzbekAudio(inputAudio, mimeType || "audio/webm");
    const botState = botManager.getSnapshot();
    const turn = await generateUzbekCompanionTurn(transcript, botState, history);
    const parsedCount = turn.targetCount ?? parseTargetCountFromText(transcript);

    executeAiAction(
      turn.action,
      turn.targetPlayer,
      turn.inGameMessage || (botState.config.relayAiToGameChat ? turn.replyUzbek : undefined),
      parsedCount
    );

    let audioBase64: string | undefined;
    let audioMimeType: string | undefined;
    let ttsError: string | undefined;

    if (speak) {
      if (botState.config.ttsProvider === "gemini") {
        try {
          const tts = await synthesizeUzbekSpeech(
            turn.replyUzbek,
            botState.config.voiceName,
            "gemini"
          );
          audioBase64 = tts.audioBase64;
          audioMimeType = tts.audioMimeType;
          if (audioBase64 && botState.config.useSimpleVoiceChat) {
            void botManager.speakInSimpleVoiceChat(audioBase64);
          }
        } catch (err) {
          ttsError = err instanceof Error ? err.message : String(err);
        }
      } else if (botState.config.useSimpleVoiceChat && botState.simpleVoiceChatStatus === "connected") {
        void speakTextInGameVoice(turn.replyUzbek);
      }
    }

    res.json({
      transcript,
      ...turn,
      targetCount: parsedCount,
      audioBase64,
      audioMimeType,
      ttsError,
      state: botManager.getSnapshot(),
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

app.post("/api/ai/tts", async (req, res) => {
  try {
    const { text, voiceName, sendToGameVoice = false } = req.body as {
      text: string;
      voiceName?: string;
      sendToGameVoice?: boolean;
    };
    if (!text?.trim()) {
      res.status(400).json({ error: "Matn kiritilmadi." });
      return;
    }
    const config = botManager.getConfig();
    const effectiveVoice = voiceName || config.voiceName;
    const provider = config.ttsProvider === "browser" && !sendToGameVoice ? "browser" : "gemini";
    const tts = await synthesizeUzbekSpeech(text.trim(), effectiveVoice, provider);
    if (sendToGameVoice && tts.audioBase64) {
      void botManager.speakInSimpleVoiceChat(tts.audioBase64);
    }
    res.json(tts);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

function requireDistExists(distPath: string) { return fs.existsSync(path.join(distPath, "index.html")); }

async function startServer() {
  const isProd = process.env.NODE_ENV === "production";

  if (!isProd) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    if (requireDistExists(distPath)) {
      app.use(express.static(distPath));
      app.get("*", (_req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    } else {
      app.get("/", (_req, res) => res.json({ service: "Alpomish API", health: "/health" }));
    }
  }

  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Alpomish MC serveri http://0.0.0.0:${PORT} portida ishga tushdi`);
  });
}

startServer();
