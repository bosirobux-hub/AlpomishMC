import { GoogleGenAI, Type } from "@google/genai";
import {
  AiActionType,
  AiProvider,
  AiTurnResult,
  BotStateSnapshot,
  ProviderAvailability,
  TtsProvider,
} from "./types.js";

const GEMINI_VOICE_DESIGN_PERSONAS: Record<
  string,
  { baseVoice: string; style: string }
> = {
  Alpomish_Baxshi: {
    baseVoice: "Fenrir",
    style: "Heroic, warm, deep Uzbek warrior companion voice, clear diction",
  },
  Sokin_Ustoz: {
    baseVoice: "Charon",
    style: "Calm, wise, measured tactical guide voice speaking clear Uzbek",
  },
  Qiziqarli_Dost: {
    baseVoice: "Puck",
    style: "Energetic, cheerful young gaming teammate voice, upbeat tone",
  },
  Mehrli_Hamroh: {
    baseVoice: "Kore",
    style: "Warm, clear, supportive female teammate voice speaking Uzbek",
  },
  Tezkor_Razvedka: {
    baseVoice: "Zephyr",
    style: "Brisk, crisp scout voice, clear Uzbek pronunciation",
  },
};

const STANDARD_GEMINI_VOICES = new Set([
  "Charon",
  "Kore",
  "Puck",
  "Fenrir",
  "Zephyr",
  "Aoede",
  "Orus",
  "Leda",
]);

const VALID_ACTIONS = new Set<AiActionType>([
  "none",
  "chop_wood",
  "speedrun",
  "follow_player",
  "mine_ores",
  "guard",
  "hunt_food",
  "collect_drops",
  "farm_crops",
  "fish",
  "torch_place",
  "sleep_bed",
  "build_pillar",
  "stop_task",
  "say_in_game",
  "come_here",
]);

export function getProviderAvailability(): ProviderAvailability {
  return {
    gemini: Boolean(process.env.GEMINI_API_KEY?.trim()),
  };
}

function getAiClient(apiVersion?: string): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GEMINI_API_KEY topilmadi. Iltimos, AI Studio Settings > Secrets bo'limida API kalitini tekshiring."
    );
  }
  return new GoogleGenAI({
    apiKey,
    ...(apiVersion ? { apiVersion } : {}),
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function formatUzbekApiError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw.includes("503") || raw.includes("UNAVAILABLE") || raw.includes("overloaded")) {
    return "Sun'iy intellekt serveri hozir juda band (503). Iltimos, 5-10 soniyadan keyin qayta urinib ko'ring.";
  }
  if (raw.includes("429") || raw.includes("RESOURCE_EXHAUSTED")) {
    return "So'rovlar limiti vaqtincha tugadi (429). Biroz kutib qayta urinib ko'ring.";
  }
  if (
    raw.includes("403") ||
    raw.includes("401") ||
    raw.includes("PERMISSION_DENIED") ||
    raw.includes("API_KEY_INVALID") ||
    raw.includes("authentication_error")
  ) {
    return "API kaliti noto'g'ri yoki ruxsat berilmagan. Settings > Secrets bo'limini tekshiring.";
  }
  return raw;
}

async function withBackoff<T>(fn: () => Promise<T>, maxAttempts = 3): Promise<T> {
  let lastErr: unknown;
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      const msg = err instanceof Error ? err.message : String(err);
      const isTransient =
        msg.includes("503") ||
        msg.includes("UNAVAILABLE") ||
        msg.includes("429") ||
        msg.includes("ECONNRESET") ||
        msg.includes("ETIMEDOUT");
      if (!isTransient || attempt === maxAttempts - 1) {
        throw err;
      }
      await new Promise((r) => setTimeout(r, 700 * (attempt + 1)));
    }
  }
  throw lastErr;
}

export async function transcribeUzbekAudio(
  base64Audio: string,
  mimeType: string
): Promise<string> {
  const ai = getAiClient();

  const tryTranscribe = async (model: string) =>
    withBackoff(() =>
      ai.models.generateContent({
        model,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: mimeType || "audio/webm",
                data: base64Audio,
              },
            },
            {
              text: "Foydalanuvchi o'zbek tilida Minecraft yordamchi botiga murojaat qilyapti. Faqat eshitilgan o'zbekcha nutqni to'g'ri va aniq matn ko'rinishida yozib ber. Qo'shimcha izoh qo'shma.",
            },
          ],
        },
      })
    );

  let response;
  try {
    response = await tryTranscribe("gemini-3.5-transcribe");
  } catch {
    try {
      response = await tryTranscribe("gemini-4-hydrogen");
    } catch (err) {
      throw new Error(formatUzbekApiError(err));
    }
  }

  const text = (response.text ?? "").trim();
  if (!text) {
    throw new Error("Ovozdan matn ajratib bo'lmadi. Iltimos, balandroq va aniqroq gapiring.");
  }
  return text;
}

function buildCompanionPrompts(
  userMessage: string,
  botState: BotStateSnapshot,
  history: Array<{ role: "user" | "assistant"; text: string }>
) {
  const stateSummary = [
    `Bot holati: ${botState.status}`,
    `Server: ${botState.config.serverLink} (${botState.config.versionLabel}, Cracked)`,
    `Bot niki: ${botState.config.username}`,
    `Hozirgi vazifa: ${botState.activeTask} (${botState.taskDetail})`,
    `Jon/Ochlik: ${botState.health}/20 HP, ${botState.food}/20`,
    `Yaqin o'yinchilar: ${botState.nearbyPlayers.join(", ") || "ko'rinmadi"}`,
    `Qazilgan bloklar: ${botState.blocksMinedCount}`,
  ].join(" | ");

  const recentHistory = history
    .slice(-6)
    .map((m) => `${m.role === "user" ? "O'yinchi" : "Hamroh"}: ${m.text}`)
    .join("\n");

  const systemInstruction = `Sen Minecraft o'yinida o'yinchi bilan birga o'ynaydigan o'zbek tilidagi hamrohsan.
QAT'IY QOIDALAR:
1. Faqat O'ZBEK tilida (lotin alifbosida) javob ber. Boshqa tillarda gapirma.
2. O'zingni HECH QACHON reklama qilma: ilova nomini, saytni, model nomini, "men AI man", "men sun'iy intellektman" yoki "men yordamchi botman" kabi gaplarni aytma. Oddiy do'st va jamoadosh kabi tabiiy, qisqa (1-2 gap) javob ber.
3. O'yinchi buyruq bersa, mos "action" qiymatini aniq tanla:
   - "chop_wood": daraxt chopish / yog'och yig'ish
   - "speedrun": speedrun boshlash / dragon o'ldirishga tayyorlanish
   - "follow_player": o'yinchi orqasidan yurish / ergashish / kelish
   - "mine_ores": tosh, ko'mir, temir, olmos qazish
   - "guard": moblardan qo'riqlash / jang qilish
   - "hunt_food": ovqat topish / hayvon ovlash / ochlikni to'ydirish
   - "collect_drops": yerdagi tushgan buyumlarni yig'ish / terish
   - "farm_crops": ekinlarni yig'ish / dehqonchilik qilish
   - "fish": baliq tutish / qarmoq tashlash
   - "torch_place": mash'ala qo'yish / chiroq yoqish
   - "sleep_bed": krovatda uxlash / tunni o'tkazish
   - "build_pillar": himoya minorasi / ustun qurish
   - "stop_task": to'xtash / kutish / bekor qilish ("bekor qilindi", "to'xta")
   - "say_in_game": o'yin ichidagi chatga xabar yozish
   - "none": oddiy suhbat yoki savol-javob
4. Agar o'yinchi son aytsa (masalan: "64 ta daraxt chop" yoki "32 ta tosh qaz"), "targetCount" ga shu sonni yoz.
5. Agar bot hozir serverga ulanmagan bo'lsa ham, vazifani qabul qilganingni ayt va ulanish tugmasini bosishni eslat.`;

  const prompt = `Hozirgi bot holati: ${stateSummary}
${recentHistory ? `\nOxirgi suhbat:\n${recentHistory}\n` : ""}
O'yinchining yangi xabari: "${userMessage}"`;

  return { systemInstruction, prompt };
}

function parseCompanionJson(rawText: string) {
  let cleaned = rawText.trim();
  const fenceMatch = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenceMatch && fenceMatch[1]) {
    cleaned = fenceMatch[1].trim();
  }
  let parsed: {
    replyUzbek?: string;
    action?: string;
    targetCount?: number;
    targetPlayer?: string;
    inGameMessage?: string;
  } = {};

  try {
    parsed = JSON.parse(cleaned);
  } catch {
    parsed = { replyUzbek: cleaned || "Tushundim, do'stim!", action: "none" };
  }

  const action: AiActionType = VALID_ACTIONS.has(parsed.action as AiActionType)
    ? (parsed.action as AiActionType)
    : "none";

  const targetCount =
    typeof parsed.targetCount === "number" &&
    Number.isFinite(parsed.targetCount) &&
    parsed.targetCount > 0
      ? Math.min(2304, Math.round(parsed.targetCount))
      : undefined;

  return {
    replyUzbek: parsed.replyUzbek || "Tushundim, do'stim!",
    action,
    targetCount,
    targetPlayer: parsed.targetPlayer,
    inGameMessage: parsed.inGameMessage,
  };
}

export async function generateUzbekCompanionTurn(
  userMessage: string,
  botState: BotStateSnapshot,
  history: Array<{ role: "user" | "assistant"; text: string }>
): Promise<Omit<AiTurnResult, "audioBase64" | "audioMimeType" | "ttsError">> {
  const { systemInstruction, prompt } = buildCompanionPrompts(
    userMessage,
    botState,
    history
  );

  const ai = getAiClient();
  const primaryModel =
    botState.config.aiModel === "gemini-3.1-flash-lite"
      ? "gemini-3.1-flash-lite"
      : "gemini-4-hydrogen";
  const fallbackModel =
    primaryModel === "gemini-4-hydrogen"
      ? "gemini-3.1-flash-lite"
      : "gemini-4-hydrogen";

  const callModel = (model: string) =>
    withBackoff(() =>
      ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              replyUzbek: {
                type: Type.STRING,
                description: "O'zbek tilida qisqa va tabiiy javob.",
              },
              action: {
                type: Type.STRING,
                description:
                  "Bajariladigan Minecraft bot harakati: none, chop_wood, speedrun, follow_player, mine_ores, guard, hunt_food, collect_drops, farm_crops, fish, torch_place, sleep_bed, build_pillar, stop_task, say_in_game, come_here",
              },
              targetCount: {
                type: Type.INTEGER,
                description: "Agar ma'lum sonli buyum yig'ish buyurilgan bo'lsa (masalan 64), o'sha son.",
              },
              targetPlayer: {
                type: Type.STRING,
                description: "Agar o'yinchi nomi aytilgan bo'lsa, uning niki.",
              },
              inGameMessage: {
                type: Type.STRING,
                description: "Agar o'yin ichidagi chatga xabar yozish kerak bo'lsa, qisqa matn.",
              },
            },
            required: ["replyUzbek", "action"],
          },
        },
      })
    );

  let response;
  let usedModel = primaryModel;
  try {
    response = await callModel(primaryModel);
  } catch {
    try {
      usedModel = fallbackModel;
      response = await callModel(fallbackModel);
    } catch (err) {
      throw new Error(formatUzbekApiError(err));
    }
  }

  return {
    ...parseCompanionJson(response.text ?? "{}"),
    providerUsed: "gemini",
    modelUsed: usedModel,
  };
}

export async function synthesizeUzbekSpeech(
  text: string,
  voiceName = "Charon",
  ttsProvider: TtsProvider = "gemini"
): Promise<{ audioBase64: string; audioMimeType: string }> {
  if (ttsProvider === "browser") {
    return { audioBase64: "", audioMimeType: "text/plain" };
  }

  const persona = GEMINI_VOICE_DESIGN_PERSONAS[voiceName];
  const resolvedVoice =
    persona?.baseVoice ||
    (STANDARD_GEMINI_VOICES.has(voiceName) ? voiceName : "Charon");
  const ttsModel = persona ? "gemini-3.8-flash-tts" : "gemini-3.8-flash-lite-tts";
  const styleText =
    persona?.style || "Friendly, clear, natural Uzbek gaming companion voice";

  const attempts: Array<{
    apiVersion?: string;
    withMetadata: boolean;
    withSpeechConfig: boolean;
  }> = [
    { apiVersion: undefined, withMetadata: true, withSpeechConfig: true },
    { apiVersion: "v1alpha", withMetadata: true, withSpeechConfig: true },
    { apiVersion: "v1beta", withMetadata: false, withSpeechConfig: true },
    { apiVersion: undefined, withMetadata: false, withSpeechConfig: false },
  ];

  let lastErr: unknown;

  for (const cfg of attempts) {
    try {
      const ai = getAiClient(cfg.apiVersion);
      const part: Record<string, unknown> = { text };
      if (cfg.withMetadata) {
        part.speechMetadata = { style: styleText };
      }

      const configObj: Record<string, unknown> = {
        responseModalities: ["AUDIO"],
      };
      if (cfg.withSpeechConfig) {
        configObj.speechConfig = {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: resolvedVoice },
          },
        };
      }

      const response = await ai.models.generateContent({
        model: ttsModel,
        contents: [
          {
            role: "user",
            parts: [part as { text: string }],
          },
        ],
        config: configObj,
      });

      const inlineData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
      if (inlineData?.data) {
        return {
          audioBase64: inlineData.data,
          audioMimeType: inlineData.mimeType || "audio/wav",
        };
      }
    } catch (err) {
      lastErr = err;
    }
  }

  throw new Error(formatUzbekApiError(lastErr || "Ovozli javob yaratib bo'lmadi."));
}
