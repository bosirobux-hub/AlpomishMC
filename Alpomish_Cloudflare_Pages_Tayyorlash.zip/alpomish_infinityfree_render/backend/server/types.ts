export type BotConnectionStatus =
  | "offline"
  | "connecting"
  | "online"
  | "reconnecting"
  | "error";

export type BotTaskMode =
  | "idle"
  | "speedrun"
  | "chop_wood"
  | "follow_player"
  | "mine_ores"
  | "guard"
  | "hunt_food"
  | "collect_drops"
  | "farm_crops"
  | "fish"
  | "torch_place"
  | "sleep_bed"
  | "build_pillar";

export type AiProvider = "gemini";
export type TtsProvider = "gemini" | "browser";

export type LauncherType =
  | "direct_bot"
  | "tlauncher"
  | "sklauncher"
  | "legacy"
  | "prism"
  | "other";

export interface BotConfig {
  serverLink: string;
  username: string;
  versionLabel: string;
  followTarget: string;
  launcherType: LauncherType;
  authPassword: string;
  autoReconnect247: boolean;
  relayAiToGameChat: boolean;
  respondToGameChat: boolean;
  respondOnlyWhenAddressed: boolean;
  readGameChatAloud: boolean;
  useSimpleVoiceChat: boolean;
  aiProvider: AiProvider;
  aiModel: string;
  ttsProvider: TtsProvider;
  voiceName: string;
}

export interface InventoryItemSummary {
  name: string;
  count: number;
}

export interface BotInventorySlot {
  slot: number;
  name: string;
  displayName: string;
  count: number;
}

export interface BotWorldBlock {
  x: number;
  y: number;
  z: number;
  name: string;
}

export interface BotWorldEntity {
  name: string;
  kind: "player" | "hostile" | "animal" | "item" | "other";
  x: number;
  y: number;
  z: number;
  distance: number;
}

export interface BotViewSnapshot {
  online: boolean;
  username: string;
  status: BotConnectionStatus;
  statusMessage: string;
  position: { x: number; y: number; z: number } | null;
  yaw: number;
  pitch: number;
  dimension: string;
  biome: string;
  timeOfDay: number;
  health: number;
  food: number;
  heldSlot: number;
  slots: BotInventorySlot[];
  blocks: BotWorldBlock[];
  entities: BotWorldEntity[];
}

export interface BotLogEntry {
  id: string;
  timestamp: string;
  level: "info" | "success" | "warn" | "error" | "chat";
  text: string;
}

export interface InGameChatMessage {
  id: string;
  timestamp: string;
  sender: string;
  message: string;
  isBot: boolean;
  isSystem: boolean;
}

export type SimpleVoiceChatStatus =
  | "inactive"
  | "requested"
  | "connected"
  | "unsupported";

export interface BotStateSnapshot {
  status: BotConnectionStatus;
  statusMessage: string;
  config: BotConfig;
  activeTask: BotTaskMode;
  taskDetail: string;
  targetCount: number | null;
  collectedCount: number;
  health: number;
  food: number;
  position: { x: number; y: number; z: number } | null;
  dimension: string;
  nearbyPlayers: string[];
  inventory: InventoryItemSummary[];
  uptimeSeconds: number;
  reconnectCount: number;
  speedrunStage: string;
  blocksMinedCount: number;
  simpleVoiceChatStatus: SimpleVoiceChatStatus;
  simpleVoiceChatMessage: string;
  logs: BotLogEntry[];
  inGameChat: InGameChatMessage[];
}

export type AiActionType =
  | "none"
  | "chop_wood"
  | "speedrun"
  | "follow_player"
  | "mine_ores"
  | "guard"
  | "hunt_food"
  | "collect_drops"
  | "farm_crops"
  | "fish"
  | "torch_place"
  | "sleep_bed"
  | "build_pillar"
  | "stop_task"
  | "say_in_game"
  | "come_here";

export interface AiTurnResult {
  transcript?: string;
  replyUzbek: string;
  action: AiActionType;
  targetCount?: number;
  targetPlayer?: string;
  inGameMessage?: string;
  providerUsed?: AiProvider;
  modelUsed?: string;
  audioBase64?: string;
  audioMimeType?: string;
  ttsError?: string;
}

export interface ProviderAvailability {
  gemini: boolean;
}
