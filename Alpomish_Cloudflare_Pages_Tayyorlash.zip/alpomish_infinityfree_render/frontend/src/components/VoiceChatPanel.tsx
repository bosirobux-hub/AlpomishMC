import { apiUrl } from "../api";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  Mic,
  MicOff,
  Radio,
  Send,
  Volume2,
  VolumeX,
} from "lucide-react";
import {
  ChatTurn,
  InGameChatMessage,
  SimpleVoiceChatStatus,
  TtsProvider,
  VoiceOption,
} from "../types";

interface VoiceChatPanelProps {
  botUsername: string;
  voiceName: string;
  onChangeVoice: (voice: VoiceOption) => void;
  ttsProvider: TtsProvider;
  onChangeTtsProvider: (provider: TtsProvider) => void;
  relayToGame: boolean;
  onToggleRelay: () => void;
  respondToGameChat: boolean;
  onToggleRespondGameChat: () => void;
  respondOnlyWhenAddressed: boolean;
  onToggleRespondOnlyWhenAddressed: () => void;
  readGameChatAloud: boolean;
  onToggleReadGameChatAloud: () => void;
  useSimpleVoiceChat: boolean;
  onToggleSimpleVoiceChat: () => void;
  simpleVoiceChatStatus: SimpleVoiceChatStatus;
  simpleVoiceChatMessage: string;
  inGameChat: InGameChatMessage[];
  botStatus: string;
}

const EASE = [0.22, 1, 0.36, 1] as const;

const VOICES: Array<{ id: VoiceOption; label: string; group: string }> = [
  { id: "Alpomish_Baxshi", label: "Alpomish Baxshi (Jangovor chuqur o'zbek ovozi)", group: "Maxsus" },
  { id: "Sokin_Ustoz", label: "Sokin Ustoz (Bosiq maslahatchi ovoz)", group: "Maxsus" },
  { id: "Qiziqarli_Dost", label: "Qiziqarli Do'st (Quvnoq yosh ovoz)", group: "Maxsus" },
  { id: "Mehrli_Hamroh", label: "Mehrli Hamroh (Aniq ayol hamroh ovozi)", group: "Maxsus" },
  { id: "Tezkor_Razvedka", label: "Tezkor Razvedka (Chaqqon razvedkachi ovozi)", group: "Maxsus" },
  { id: "Charon", label: "Charon (Sokin chuqur erkak ovozi)", group: "Standart" },
  { id: "Kore", label: "Kore (Aniq yumshoq ayol ovozi)", group: "Standart" },
  { id: "Puck", label: "Puck (Tezkor yosh yigit ovozi)", group: "Standart" },
  { id: "Fenrir", label: "Fenrir (Kuchli jangovar ovoz)", group: "Standart" },
  { id: "Zephyr", label: "Zephyr (Yengil do'stona ovoz)", group: "Standart" },
  { id: "Aoede", label: "Aoede (Ohangdor ravon ovoz)", group: "Standart" },
  { id: "Orus", label: "Orus (Qat'iy sardor ovoz)", group: "Standart" },
  { id: "Leda", label: "Leda (Tiniq sokin ovoz)", group: "Standart" },
];

function AnimatedVoiceBars({ active }: { active: boolean }) {
  return (
    <span className="inline-flex items-end gap-0.5 h-3.5" aria-hidden="true">
      {[0.4, 0.9, 0.6, 1, 0.5].map((scale, i) => (
        <motion.span
          key={i}
          className="w-0.5 rounded-full bg-[#D97757]"
          animate={
            active
              ? { height: ["35%", `${Math.round(scale * 100)}%`, "35%"] }
              : { height: "35%" }
          }
          transition={
            active
              ? {
                  duration: 0.75 + i * 0.1,
                  repeat: Infinity,
                  ease: "easeInOut",
                }
              : { duration: 0.2 }
          }
        />
      ))}
    </span>
  );
}

export function VoiceChatPanel({
  botUsername,
  voiceName,
  onChangeVoice,
  ttsProvider,
  onChangeTtsProvider,
  relayToGame,
  onToggleRelay,
  respondToGameChat,
  onToggleRespondGameChat,
  respondOnlyWhenAddressed,
  onToggleRespondOnlyWhenAddressed,
  readGameChatAloud,
  onToggleReadGameChatAloud,
  useSimpleVoiceChat,
  onToggleSimpleVoiceChat,
  simpleVoiceChatStatus,
  simpleVoiceChatMessage,
  inGameChat,
  botStatus,
}: VoiceChatPanelProps) {
  const [messages, setMessages] = useState<ChatTurn[]>([
    {
      id: "welcome-1",
      role: "assistant",
      text: `Salom! Men ${botUsername}. Mikrofondan gapiring yoki chatga yozing — masalan, "daraxt qazi 64 ta" desangiz bolta yasab 64 tagacha chopaman, "bekor qilindi" desangiz darhol to'xtayman.`,
      timestamp: new Date().toLocaleTimeString("uz-UZ", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      }),
    },
  ]);

  const [input, setInput] = useState("");
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [playingId, setPlayingId] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const quickPrompts = [
    `${botUsername} daraxt qazi 64 ta`,
    "Orqamdan yur, meni himoya qil",
    "Speedrun rejimini boshla",
    "Kon qazib 32 ta tosh va temir top",
    `${botUsername} bekor qilindi`,
  ];

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages]);

  function playBase64Wav(id: string, base64: string, mimeType = "audio/wav") {
    try {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      const audio = new Audio(`data:${mimeType};base64,${base64}`);
      audioRef.current = audio;
      setPlayingId(id);
      audio.onended = () => setPlayingId(null);
      audio.onerror = () => setPlayingId(null);
      void audio.play();
    } catch {
      setPlayingId(null);
    }
  }

  function speakBrowserFallback(text: string) {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      const voices = window.speechSynthesis.getVoices();
      const uzOrTr =
        voices.find((v) => v.lang.toLowerCase().startsWith("uz")) ||
        voices.find((v) => v.lang.toLowerCase().startsWith("tr")) ||
        voices[0];
      if (uzOrTr) utter.voice = uzOrTr;
      utter.lang = uzOrTr?.lang || "uz-UZ";
      utter.rate = 1.0;
      window.speechSynthesis.speak(utter);
    } catch {
      // ignore
    }
  }

  async function handleTestVoice() {
    if (isTestingVoice) return;
    setErrorMsg(null);
    const sampleText = `Salom! Men ${botUsername}, siz bilan Minecraft dunyosida birga o'ynashga tayyorman.`;
    if (ttsProvider === "browser") {
      speakBrowserFallback(sampleText);
      return;
    }
    setIsTestingVoice(true);
    try {
      const res = await fetch(apiUrl("/api/ai/tts"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: sampleText,
          voiceName,
          sendToGameVoice: useSimpleVoiceChat,
        }),
      });
      const data = (await res.json()) as {
        audioBase64?: string;
        audioMimeType?: string;
        error?: string;
      };
      if (!res.ok) {
        throw new Error(data.error || "Ovozni sinashda xato yuz berdi.");
      }
      if (data.audioBase64) {
        playBase64Wav("voice-test", data.audioBase64, data.audioMimeType);
      } else {
        speakBrowserFallback(sampleText);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : String(err));
    } finally {
      setIsTestingVoice(false);
    }
  }

  async function handleSendText(textToSend: string) {
    const clean = textToSend.trim();
    if (!clean || isSending) return;

    setErrorMsg(null);
    setInput("");
    const now = new Date().toLocaleTimeString("uz-UZ", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
    });

    const userTurn: ChatTurn = {
      id: `u-${Date.now()}`,
      role: "user",
      text: clean,
      timestamp: now,
    };
    const nextHistory = [...messages, userTurn];
    setMessages(nextHistory);
    setIsSending(true);

    try {
      const res = await fetch(apiUrl("/api/ai/chat"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: clean,
          history: nextHistory.slice(-8).map((m) => ({ role: m.role, text: m.text })),
          speak: autoSpeak,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Sun'iy intellekt bilan bog'lanishda xato");
      }

      const aiId = `a-${Date.now()}`;
      const countNote = data.targetCount ? ` (${data.targetCount} ta)` : "";
      const aiTurn: ChatTurn = {
        id: aiId,
        role: "assistant",
        text: data.replyUzbek,
        timestamp: new Date().toLocaleTimeString("uz-UZ", {
          hour12: false,
          hour: "2-digit",
          minute: "2-digit",
        }),
        actionLabel:
          data.action && data.action !== "none"
            ? `Buyruq: ${data.action}${countNote}`
            : undefined,
        audioBase64: data.audioBase64,
        audioMimeType: data.audioMimeType,
      };
      setMessages((prev) => [...prev, aiTurn]);

      if (data.audioBase64 && autoSpeak) {
        playBase64Wav(aiId, data.audioBase64, data.audioMimeType);
      } else if (autoSpeak && data.replyUzbek) {
        speakBrowserFallback(data.replyUzbek);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : String(err));
    } finally {
      setIsSending(false);
    }
  }

  async function toggleRecording() {
    setErrorMsg(null);
    if (isRecording && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : "audio/mp4";
      const recorder = new MediaRecorder(stream, { mimeType });
      chunksRef.current = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) {
          chunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: mimeType });
        if (blob.size < 500) {
          setErrorMsg("Ovoz juda qisqa bo'ldi, iltimos qaytadan gapiring.");
          return;
        }

        setIsSending(true);
        try {
          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              const result = String(reader.result || "");
              resolve(result.split(",")[1] || "");
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });

          const res = await fetch(apiUrl("/api/ai/voice-turn"), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              audioBase64: base64,
              mimeType,
              history: messages.slice(-8).map((m) => ({ role: m.role, text: m.text })),
              speak: autoSpeak,
            }),
          });
          const data = await res.json();
          if (!res.ok) {
            throw new Error(data.error || "Ovozni qayta ishlashda xato");
          }

          const now = new Date().toLocaleTimeString("uz-UZ", {
            hour12: false,
            hour: "2-digit",
            minute: "2-digit",
          });

          const userTurn: ChatTurn = {
            id: `u-${Date.now()}`,
            role: "user",
            text: data.transcript || "(Ovozli xabar)",
            timestamp: now,
            viaMic: true,
          };

          const aiId = `a-${Date.now() + 1}`;
          const countNote = data.targetCount ? ` (${data.targetCount} ta)` : "";
          const aiTurn: ChatTurn = {
            id: aiId,
            role: "assistant",
            text: data.replyUzbek,
            timestamp: now,
            actionLabel:
              data.action && data.action !== "none"
                ? `Buyruq: ${data.action}${countNote}`
                : undefined,
            audioBase64: data.audioBase64,
            audioMimeType: data.audioMimeType,
          };

          setMessages((prev) => [...prev, userTurn, aiTurn]);
          if (data.audioBase64 && autoSpeak) {
            playBase64Wav(aiId, data.audioBase64, data.audioMimeType);
          } else if (autoSpeak && data.replyUzbek) {
            speakBrowserFallback(data.replyUzbek);
          }
        } catch (err) {
          setErrorMsg(err instanceof Error ? err.message : String(err));
        } finally {
          setIsSending(false);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
    } catch {
      setErrorMsg(
        "Mikrofonga ruxsat berilmadi. Brauzer sozlamalaridan mikrofon ruxsatini yoqing."
      );
    }
  }

  const svcBadgeColor =
    simpleVoiceChatStatus === "connected"
      ? "text-emerald-400"
      : simpleVoiceChatStatus === "requested"
      ? "text-[#E59377]"
      : "text-[#9E9B93]";

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
      {/* Left: Voice Controls, Multi-Voice Picker & Simple Voice Chat */}
      <motion.aside
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: EASE }}
        className="lg:col-span-4 bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl p-6 flex flex-col justify-between space-y-5"
      >
        <div className="space-y-4">
          <div>
            <h2 className="text-xl font-medium text-[#F5F4ED]">
              Ovozlar va Simple Voice Chat
            </h2>
            <p className="text-xs text-[#A6A39B] mt-1 leading-relaxed">
              Serverda Simple Voice Chat modi bo'lsa bot o'yin ichida ham ovoz bilan gapiradi; aks holda shu ilovada javob beradi.
            </p>
          </div>

          <motion.button
            type="button"
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            disabled={isSending}
            onClick={toggleRecording}
            className={`w-full py-4 px-4 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-colors ${
              isRecording
                ? "bg-rose-600/20 border-rose-500 text-rose-200"
                : "bg-[#D97757]/12 border-[#D97757]/55 text-[#F5F4ED] hover:bg-[#D97757]/20"
            } disabled:opacity-50`}
          >
            {isRecording ? (
              <>
                <div className="flex items-center gap-2">
                  <MicOff className="w-5 h-5 text-rose-300" />
                  <AnimatedVoiceBars active={true} />
                </div>
                <span className="text-sm font-semibold">
                  Yozishni To'xtatish va Yuborish
                </span>
              </>
            ) : (
              <>
                <Mic className="w-6 h-6 text-[#D97757]" />
                <span className="text-sm font-semibold">
                  {isSending ? "Sun'iy intellekt o'ylamoqda..." : "Mikrofon Orqali Gapirish"}
                </span>
              </>
            )}
          </motion.button>

          <div className="space-y-3 pt-2 border-t border-[#2C2B28]">
            <div>
              <label className="block text-xs font-medium text-[#C5C2BA] mb-1.5">
                Ovoz manbai
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onChangeTtsProvider("gemini")}
                  className={`px-3 py-2 rounded-xl border text-xs font-medium transition-colors ${
                    ttsProvider === "gemini"
                      ? "bg-[#D97757]/15 border-[#D97757] text-[#F5F4ED]"
                      : "bg-[#121211] border-[#2C2B28] text-[#9E9B93] hover:text-[#F5F4ED]"
                  }`}
                >
                  Gemini AI Ovozlari
                </button>
                <button
                  type="button"
                  onClick={() => onChangeTtsProvider("browser")}
                  className={`px-3 py-2 rounded-xl border text-xs font-medium transition-colors ${
                    ttsProvider === "browser"
                      ? "bg-[#D97757]/15 border-[#D97757] text-[#F5F4ED]"
                      : "bg-[#121211] border-[#2C2B28] text-[#9E9B93] hover:text-[#F5F4ED]"
                  }`}
                >
                  Brauzer Ovozi (Tez)
                </button>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-[#C5C2BA]">
                  Sun'iy intellekt ovoz tembri (13 xil)
                </label>
                <button
                  type="button"
                  disabled={isTestingVoice}
                  onClick={() => void handleTestVoice()}
                  className="text-xs font-medium text-[#E59377] hover:text-[#F0AD95] disabled:opacity-50"
                >
                  {isTestingVoice ? "Tayyorlanmoqda..." : "Ovozni sinash"}
                </button>
              </div>
              <select
                value={voiceName}
                onChange={(e) => onChangeVoice(e.target.value as VoiceOption)}
                className="w-full px-3 py-2.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm text-[#F5F4ED] focus:outline-none focus:border-[#D97757]"
              >
                <optgroup label="O'zbekcha Xarakter Ovozlari (Voice Design)">
                  {VOICES.filter((v) => v.group === "Maxsus").map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.label}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Standart Sun'iy Intellekt Ovozlari">
                  {VOICES.filter((v) => v.group === "Standart").map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.label}
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            <div className="p-3 rounded-xl bg-[#121211] border border-[#2C2B28] space-y-2">
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#F5F4ED]">
                  <Radio className="w-3.5 h-3.5 text-[#D97757]" />
                  <span>Simple Voice Chat (O'yinda)</span>
                </span>
                <button
                  type="button"
                  onClick={onToggleSimpleVoiceChat}
                  className="text-xs font-mono text-[#E59377] hover:text-[#F0AD95]"
                >
                  {useSimpleVoiceChat ? "YOQILGAN" : "O'CHIQ"}
                </button>
              </div>
              <p className={`text-[11px] leading-relaxed ${svcBadgeColor}`}>
                {simpleVoiceChatMessage}
              </p>
            </div>

            {[
              {
                label: `Faqat bot nomi (${botUsername}) aytilganda javob berish`,
                active: respondOnlyWhenAddressed,
                onClick: onToggleRespondOnlyWhenAddressed,
              },
              {
                label: "Ovozli javobni avtomatik o'qish",
                active: autoSpeak,
                onClick: () => setAutoSpeak((prev) => !prev),
                icon: autoSpeak ? (
                  <Volume2 className="w-4 h-4 text-[#D97757]" />
                ) : (
                  <VolumeX className="w-4 h-4 text-[#7C7971]" />
                ),
              },
              {
                label: "Javobni o'yin chatiga ham yozish",
                active: relayToGame,
                onClick: onToggleRelay,
              },
              {
                label: "O'yin chatidagi buyruqlarni bajarish",
                active: respondToGameChat,
                onClick: onToggleRespondGameChat,
              },
              {
                label: "O'yin chatini ovozli o'qib berish",
                active: readGameChatAloud,
                onClick: onToggleReadGameChatAloud,
              },
            ].map((item) => (
              <motion.button
                key={item.label}
                type="button"
                whileTap={{ scale: 0.985 }}
                onClick={item.onClick}
                className="w-full flex items-center justify-between px-3.5 py-2.5 bg-[#121211] border border-[#2C2B28] rounded-xl text-xs text-[#E5E3DC] hover:border-[#3E3C37] transition-colors text-left gap-2"
              >
                <span className="inline-flex items-center gap-2">
                  {item.icon}
                  <span>{item.label}</span>
                </span>
                <span
                  className={`font-mono shrink-0 ${
                    item.active ? "text-[#E59377]" : "text-[#6E6B64]"
                  }`}
                >
                  {item.active ? "YOQILGAN" : "O'CHIQ"}
                </span>
              </motion.button>
            ))}
          </div>
        </div>

        <div className="pt-3 border-t border-[#2C2B28] text-xs text-[#9E9B93]">
          Bot holati: <span className="text-[#F5F4ED] font-medium">{botStatus}</span>
        </div>
      </motion.aside>

      {/* Right: Editorial Conversation Canvas */}
      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.34, delay: 0.06, ease: EASE }}
        className="lg:col-span-8 bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl flex flex-col h-[690px]"
      >
        <div className="px-5 py-4 border-b border-[#2C2B28] flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-[#F5F4ED]">
              {botUsername} bilan Ovozli va Matnli Suhbat
            </h3>
            <p className="text-xs text-[#A6A39B] mt-0.5">
              O'yinda "{botUsername} daraxt qazi 64 ta" yoki "{botUsername} bekor qilindi" deb yozishingiz ham mumkin.
            </p>
          </div>
          <span className="text-xs text-[#9E9B93] font-mono tabular-nums">
            {messages.length} xabar
          </span>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-4">
          {inGameChat.length > 0 && (
            <div className="rounded-2xl border border-[#2C2B28] bg-[#121211] p-3.5 space-y-2">
              <div className="flex items-center justify-between text-xs font-medium text-[#A6A39B] border-b border-[#272623] pb-2">
                <span>Jonli Minecraft O'yin Chati</span>
                <span className="font-mono tabular-nums">{inGameChat.length} ta xabar</span>
              </div>
              <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                {inGameChat.slice(-15).map((g) => (
                  <div
                    key={g.id}
                    className="flex items-start justify-between gap-3 text-xs leading-relaxed"
                  >
                    <div className="min-w-0">
                      <span className="font-mono text-[#7C7971] mr-2 tabular-nums">
                        {g.timestamp}
                      </span>
                      <span
                        className={`font-semibold mr-1.5 ${
                          g.isBot
                            ? "text-emerald-400"
                            : g.isSystem
                            ? "text-[#E59377]"
                            : "text-sky-400"
                        }`}
                      >
                        {g.sender}:
                      </span>
                      <span className="text-[#E5E3DC] break-words">{g.message}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        speakBrowserFallback(
                          g.isSystem ? g.message : `${g.sender} yozdi: ${g.message}`
                        )
                      }
                      className="text-[#D97757] hover:text-[#E59377] shrink-0"
                      title="Ovozli o'qish"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <AnimatePresence initial={false}>
            {messages.map((msg) => {
              const isUser = msg.role === "user";
              const isSpeaking = playingId === msg.id;
              return (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10, scale: 0.985 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ duration: 0.24, ease: EASE }}
                  className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}
                >
                  <div
                    className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-relaxed border ${
                      isUser
                        ? "bg-[#D97757]/14 border-[#D97757]/45 text-[#F5F4ED]"
                        : "bg-[#141413] border-[#2C2B28] text-[#EAE8E0]"
                    }`}
                  >
                    <p>{msg.text}</p>
                    <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-[#9E9B93]">
                      <span className="font-mono tabular-nums">{msg.timestamp}</span>
                      {msg.viaMic && <span>· Mikrofondan</span>}
                      {msg.actionLabel && (
                        <span className="text-[#E59377] font-medium">
                          · {msg.actionLabel}
                        </span>
                      )}
                      {!isUser && (
                        <button
                          type="button"
                          onClick={() =>
                            msg.audioBase64
                              ? playBase64Wav(msg.id, msg.audioBase64, msg.audioMimeType)
                              : speakBrowserFallback(msg.text)
                          }
                          className="inline-flex items-center gap-1.5 text-[#D97757] hover:text-[#E59377] font-medium"
                        >
                          {isSpeaking ? (
                            <AnimatedVoiceBars active={true} />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                          <span>{isSpeaking ? "O'qilmoqda..." : "Tinglash"}</span>
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {errorMsg && (
          <div className="mx-5 mb-3 px-3.5 py-2.5 rounded-xl bg-rose-950/50 border border-rose-800 text-xs text-rose-200">
            {errorMsg}
          </div>
        )}

        <div className="p-4 border-t border-[#2C2B28] space-y-3">
          <div className="flex flex-wrap gap-2">
            {quickPrompts.map((q) => (
              <motion.button
                key={q}
                type="button"
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.97 }}
                disabled={isSending}
                onClick={() => void handleSendText(q)}
                className="px-3 py-1.5 rounded-xl bg-[#141413] border border-[#2C2B28] hover:border-[#4A4843] text-xs text-[#D1CEC5] hover:text-[#F5F4ED] transition-colors whitespace-nowrap"
              >
                {q}
              </motion.button>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void handleSendText(input);
            }}
            className="flex items-center gap-2.5"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`O'zbek tilida yozing (masalan: ${botUsername} daraxt qazi 64 ta)...`}
              className="flex-1 px-4 py-2.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm text-[#F5F4ED] placeholder:text-[#6E6B64] focus:outline-none focus:border-[#D97757]"
            />
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              disabled={isSending || !input.trim()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#D97757] hover:bg-[#E38567] text-[#141413] text-sm font-semibold transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>Yuborish</span>
            </motion.button>
          </form>
        </div>
      </motion.section>
    </div>
  );
}
