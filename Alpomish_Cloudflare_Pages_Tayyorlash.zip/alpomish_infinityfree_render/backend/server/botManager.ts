import mineflayer, { Bot } from "mineflayer";
import pathfinderPkg from "mineflayer-pathfinder";
import type { Response } from "express";
import { SimpleVoiceChatBridge } from "./simpleVoiceChat.js";
import {
  BotConfig,
  BotConnectionStatus,
  BotInventorySlot,
  BotLogEntry,
  BotStateSnapshot,
  BotTaskMode,
  BotViewSnapshot,
  BotWorldBlock,
  BotWorldEntity,
  InGameChatMessage,
  InventoryItemSummary,
} from "./types.js";

const { pathfinder, Movements, goals } = pathfinderPkg;

const LOG_NAMES = [
  "oak_log",
  "birch_log",
  "spruce_log",
  "dark_oak_log",
  "acacia_log",
  "jungle_log",
  "cherry_log",
  "mangrove_log",
];

const ORE_NAMES = [
  "diamond_ore",
  "deepslate_diamond_ore",
  "iron_ore",
  "deepslate_iron_ore",
  "coal_ore",
  "deepslate_coal_ore",
  "gold_ore",
  "copper_ore",
  "cobblestone",
  "stone",
];

const HOSTILE_MOBS = new Set([
  "zombie",
  "skeleton",
  "spider",
  "cave_spider",
  "creeper",
  "enderman",
  "witch",
  "pillager",
  "drowned",
  "husk",
  "stray",
  "phantom",
]);

const FOOD_ANIMALS = new Set(["cow", "pig", "sheep", "chicken", "rabbit"]);

const EDIBLE_ITEMS = new Set([
  "cooked_beef",
  "cooked_porkchop",
  "cooked_mutton",
  "cooked_chicken",
  "bread",
  "baked_potato",
  "apple",
  "carrot",
  "melon_slice",
  "sweet_berries",
  "cooked_cod",
  "cooked_salmon",
  "beef",
  "porkchop",
  "mutton",
  "chicken",
]);

const CROP_NAMES = new Set(["wheat", "carrots", "potatoes", "beetroots"]);

const BUILD_BLOCKS = [
  "cobblestone",
  "dirt",
  "oak_planks",
  "spruce_planks",
  "birch_planks",
  "netherrack",
  "stone",
];

function parseServerAddress(rawLink: string): { host: string; port?: number; display: string } {
  const cleaned = rawLink
    .trim()
    .replace(/^minecraft:\/\//i, "")
    .replace(/^https?:\/\//i, "")
    .split("/")[0];

  if (!cleaned) {
    return { host: "scrubbed-bust.eu.e4mc.link", display: "scrubbed-bust.eu.e4mc.link" };
  }

  const colonIdx = cleaned.lastIndexOf(":");
  if (colonIdx > 0) {
    const hostPart = cleaned.slice(0, colonIdx);
    const portPart = Number.parseInt(cleaned.slice(colonIdx + 1), 10);
    if (hostPart && Number.isFinite(portPart) && portPart > 0 && portPart <= 65535) {
      return { host: hostPart, port: portPart, display: `${hostPart}:${portPart}` };
    }
  }
  return { host: cleaned, display: cleaned };
}

function extractMcText(node: unknown): string {
  if (typeof node === "string") return node;
  if (!node || typeof node !== "object") return "";
  if (Array.isArray(node)) return node.map(extractMcText).join("");

  const obj = node as Record<string, unknown>;
  if (typeof obj.type === "string" && "value" in obj) {
    if (obj.type === "string" && typeof obj.value === "string") {
      return obj.value;
    }
    if (obj.type === "list" && obj.value && typeof obj.value === "object") {
      const listVal = (obj.value as Record<string, unknown>).value;
      if (Array.isArray(listVal)) {
        return listVal.map(extractMcText).join("");
      }
    }
    if (obj.type === "compound" && obj.value && typeof obj.value === "object") {
      return extractMcText(obj.value);
    }
  }

  let out = "";
  if (obj.text !== undefined) out += extractMcText(obj.text);
  if (obj[""] !== undefined) out += extractMcText(obj[""]);
  if (obj.translate !== undefined && !out) out += extractMcText(obj.translate);
  if (obj.extra !== undefined) out += extractMcText(obj.extra);
  return out;
}

function formatKickReasonUz(reason: unknown): string {
  const raw = extractMcText(reason).replace(/\s+/g, " ").trim() || String(reason);

  const lower = raw.toLowerCase();
  if (lower.includes("unknown server")) {
    return "e4mc havolasi hozir faol emas (Unknown server). O'yinda dunyoni ochib /e4mc yoki Open to LAN yoqing va yangi linkni kiriting.";
  }
  if (lower.includes("failed to verify username") || lower.includes("invalid session")) {
    return "Server litsenziyali (online-mode=true) ekan! Cracked launcher va cracked bot kirishi uchun serverda online-mode=false (yoki e4mc/LAN uchun Custom LAN / LAN Server Properties modi) yoqilgan bo'lishi kerak.";
  }
  if (lower.includes("outdated")) {
    return `Minecraft versiyasi mos kelmadi (${raw}). Versiyani tekshiring.`;
  }
  return raw;
}

function parseMinecraftVersion(versionLabel: string): string | undefined {
  const normalized = versionLabel.trim().toLowerCase();
  if (!normalized || normalized === "auto") {
    return undefined;
  }
  const match = normalized.match(/\b(\d+\.\d+(?:\.\d+)?)\b/);
  if (match && match[1]) {
    return match[1];
  }
  return "1.21.11";
}

function formatClock(): string {
  return new Date().toLocaleTimeString("uz-UZ", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (__, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= m; i += 1) {
    for (let j = 1; j <= n; j += 1) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}

export function isAddressedToBot(message: string, botUsername: string): boolean {
  const cleanMsg = message.toLowerCase().trim();
  const botLower = botUsername.toLowerCase().trim();
  if (!cleanMsg || !botLower) return false;
  if (cleanMsg.includes(botLower) || cleanMsg.includes(`@${botLower}`)) return true;

  const stem = botLower.replace(/[_-](ai|bot|mc|\d+)$/i, "").replace(/[_-]/g, "");
  const tokens = cleanMsg.split(/[^a-z0-9_]+/).filter(Boolean);
  for (const tok of tokens) {
    if (tok === botLower || (stem.length >= 4 && tok === stem)) return true;
    const maxDist = botLower.length >= 7 ? 2 : 1;
    if (Math.abs(tok.length - botLower.length) <= 2 && levenshtein(tok, botLower) <= maxDist) {
      return true;
    }
    if (
      stem.length >= 5 &&
      Math.abs(tok.length - stem.length) <= 1 &&
      levenshtein(tok, stem) <= 1
    ) {
      return true;
    }
  }
  return false;
}

class MinecraftBotManager {
  private bot: Bot | null = null;
  private status: BotConnectionStatus = "offline";
  private statusMessage = "Bot hozircha ulanmagan. Server manzilini tekshirib ulaning.";
  private config: BotConfig = {
    serverLink: "scrubbed-bust.eu.e4mc.link",
    username: "Alpomish_AI",
    versionLabel: "1.21.11 fabric",
    followTarget: "",
    launcherType: "tlauncher",
    authPassword: "",
    autoReconnect247: true,
    relayAiToGameChat: true,
    respondToGameChat: true,
    respondOnlyWhenAddressed: true,
    readGameChatAloud: true,
    useSimpleVoiceChat: true,
    aiProvider: "gemini",
    aiModel: "gemini-4-hydrogen",
    ttsProvider: "gemini",
    voiceName: "Charon",
  };

  private activeTask: BotTaskMode = "idle";
  private taskDetail = "Kutish holatida";
  private targetCount: number | null = null;
  private collectedCount = 0;
  private speedrunStage = "Tayyor (1-bosqich: Yog'och yig'ish)";
  private blocksMinedCount = 0;
  private reconnectCount = 0;
  private connectedAt: number | null = null;
  private manualDisconnect = false;
  private inGameChat: InGameChatMessage[] = [];
  private recentChatDedup = new Map<string, number>();
  private inGameChatListener: ((sender: string, message: string, isSystem: boolean) => void) | null = null;
  private voiceChatBridge: SimpleVoiceChatBridge;

  private logs: BotLogEntry[] = [
    {
      id: "init-1",
      timestamp: formatClock(),
      level: "info",
      text: "Alpomish MC yordamchisi ishga tushdi. Cracked (offline) rejim va 1.21.11 Fabric tayyor.",
    },
  ];

  private sseClients = new Set<Response>();
  private reconnectTimer: NodeJS.Timeout | null = null;
  private taskLoopTimer: NodeJS.Timeout | null = null;
  private uptimeTimer: NodeJS.Timeout | null = null;
  private isTaskStepRunning = false;

  constructor() {
    this.voiceChatBridge = new SimpleVoiceChatBridge((_status, msg) => {
      this.pushLog("info", msg);
    });
    this.uptimeTimer = setInterval(() => {
      if (this.status === "online") {
        this.broadcast();
      }
    }, 3000);
  }

  public addSseClient(res: Response) {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();

    this.sseClients.add(res);
    res.write(`data: ${JSON.stringify(this.getSnapshot())}\n\n`);

    res.on("close", () => {
      this.sseClients.delete(res);
    });
  }

  private broadcast() {
    const payload = `data: ${JSON.stringify(this.getSnapshot())}\n\n`;
    for (const client of this.sseClients) {
      try {
        client.write(payload);
      } catch {
        this.sseClients.delete(client);
      }
    }
  }

  private pushLog(level: BotLogEntry["level"], text: string) {
    const entry: BotLogEntry = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: formatClock(),
      level,
      text,
    };
    this.logs = [entry, ...this.logs].slice(0, 80);
    this.broadcast();
  }

  public updateConfig(partial: Partial<BotConfig>): BotConfig {
    this.config = {
      ...this.config,
      ...partial,
      username: (partial.username ?? this.config.username).trim().slice(0, 16) || "Alpomish_AI",
      serverLink: (partial.serverLink ?? this.config.serverLink).trim() || "scrubbed-bust.eu.e4mc.link",
      versionLabel: (partial.versionLabel ?? this.config.versionLabel).trim() || "1.21.11 fabric",
      authPassword: (partial.authPassword ?? this.config.authPassword).trim(),
    };
    this.broadcast();
    return this.config;
  }

  public getConfig(): BotConfig {
    return { ...this.config };
  }

  public async speakInSimpleVoiceChat(wavBase64?: string): Promise<boolean> {
    if (!this.config.useSimpleVoiceChat || !wavBase64) return false;
    return this.voiceChatBridge.speakWav(wavBase64);
  }

  public getSnapshot(): BotStateSnapshot {
    let inventory: InventoryItemSummary[] = [];
    let nearbyPlayers: string[] = [];
    let position: { x: number; y: number; z: number } | null = null;
    let dimension = "overworld";
    let health = 20;
    let food = 20;

    if (this.bot && this.status === "online") {
      try {
        if (this.bot.entity?.position) {
          position = {
            x: Math.round(this.bot.entity.position.x),
            y: Math.round(this.bot.entity.position.y),
            z: Math.round(this.bot.entity.position.z),
          };
        }
        health = Math.round(this.bot.health ?? 20);
        food = Math.round(this.bot.food ?? 20);
        dimension = String(this.bot.game?.dimension ?? "overworld");

        const counts = new Map<string, number>();
        for (const item of this.bot.inventory?.items() ?? []) {
          counts.set(item.name, (counts.get(item.name) ?? 0) + item.count);
        }
        inventory = Array.from(counts.entries())
          .map(([name, count]) => ({ name, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 36);

        nearbyPlayers = Object.keys(this.bot.players ?? {}).filter(
          (name) => name !== this.bot?.username
        );
      } catch {
        // Ignore transient read errors while spawning
      }
    }

    const svc = this.voiceChatBridge.getStatus();

    return {
      status: this.status,
      statusMessage: this.statusMessage,
      config: { ...this.config },
      activeTask: this.activeTask,
      taskDetail: this.taskDetail,
      targetCount: this.targetCount,
      collectedCount: this.collectedCount,
      health,
      food,
      position,
      dimension,
      nearbyPlayers,
      inventory,
      uptimeSeconds: this.connectedAt ? Math.floor((Date.now() - this.connectedAt) / 1000) : 0,
      reconnectCount: this.reconnectCount,
      speedrunStage: this.speedrunStage,
      blocksMinedCount: this.blocksMinedCount,
      simpleVoiceChatStatus: svc.status,
      simpleVoiceChatMessage: svc.message,
      logs: this.logs,
      inGameChat: this.inGameChat,
    };
  }

  public getViewSnapshot(): BotViewSnapshot {
    if (!this.bot || this.status !== "online" || !this.bot.entity?.position) {
      return {
        online: false,
        username: this.config.username,
        status: this.status,
        statusMessage: this.statusMessage,
        position: null,
        yaw: 0,
        pitch: 0,
        dimension: "overworld",
        biome: "noma'lum",
        timeOfDay: 6000,
        health: 20,
        food: 20,
        heldSlot: 0,
        slots: [],
        blocks: [],
        entities: [],
      };
    }

    const bot = this.bot;
    const pos = bot.entity.position;
    const bx = Math.floor(pos.x);
    const by = Math.floor(pos.y);
    const bz = Math.floor(pos.z);

    const slots: BotInventorySlot[] = [];
    const rawSlots = bot.inventory?.slots ?? [];
    for (let i = 0; i < rawSlots.length; i += 1) {
      const it = rawSlots[i];
      if (it) {
        slots.push({
          slot: i,
          name: it.name,
          displayName: it.displayName || it.name,
          count: it.count,
        });
      }
    }

    const blocks: BotWorldBlock[] = [];
    const TRANSPARENT = new Set(["air", "cave_air", "void_air", "water", "glass", "oak_leaves", "birch_leaves", "spruce_leaves", "dark_oak_leaves", "acacia_leaves", "jungle_leaves", "cherry_leaves"]);
    try {
      const isTransparentAt = (x: number, y: number, z: number) => {
        const b = bot.blockAt(pos.offset(x - pos.x, y - pos.y, z - pos.z));
        return !b || TRANSPARENT.has(b.name);
      };

      for (let dx = -7; dx <= 7; dx += 1) {
        for (let dy = -3; dy <= 5; dy += 1) {
          for (let dz = -7; dz <= 7; dz += 1) {
            const wx = bx + dx;
            const wy = by + dy;
            const wz = bz + dz;
            const b = bot.blockAt(pos.offset(wx - pos.x, wy - pos.y, wz - pos.z));
            if (!b || b.name === "air" || b.name === "cave_air" || b.name === "void_air") {
              continue;
            }
            const exposed =
              isTransparentAt(wx + 1, wy, wz) ||
              isTransparentAt(wx - 1, wy, wz) ||
              isTransparentAt(wx, wy + 1, wz) ||
              isTransparentAt(wx, wy - 1, wz) ||
              isTransparentAt(wx, wy, wz + 1) ||
              isTransparentAt(wx, wy, wz - 1);
            if (exposed) {
              blocks.push({ x: wx, y: wy, z: wz, name: b.name });
            }
          }
        }
      }
    } catch {
      // ignore chunk boundary errors
    }

    const entities: BotWorldEntity[] = [];
    try {
      for (const entity of Object.values(bot.entities ?? {})) {
        if (!entity || entity === bot.entity || !entity.position) continue;
        const dist = pos.distanceTo(entity.position);
        if (dist > 32) continue;
        const rawName = entity.username || entity.name || entity.displayName || "mavjudot";
        let kind: BotWorldEntity["kind"] = "other";
        if (entity.type === "player" || entity.username) {
          kind = "player";
        } else if (entity.name && HOSTILE_MOBS.has(entity.name)) {
          kind = "hostile";
        } else if (entity.name && FOOD_ANIMALS.has(entity.name)) {
          kind = "animal";
        } else if (entity.name === "item" || entity.displayName === "Item") {
          kind = "item";
        }
        entities.push({
          name: rawName,
          kind,
          x: Number(entity.position.x.toFixed(1)),
          y: Number(entity.position.y.toFixed(1)),
          z: Number(entity.position.z.toFixed(1)),
          distance: Math.round(dist * 10) / 10,
        });
      }
    } catch {
      // ignore
    }

    let biome = "o'rmon";
    try {
      const centerBlock = bot.blockAt(pos);
      if (centerBlock?.biome?.name) {
        biome = centerBlock.biome.name;
      }
    } catch {
      // ignore
    }

    return {
      online: true,
      username: bot.username || this.config.username,
      status: this.status,
      statusMessage: this.statusMessage,
      position: {
        x: Number(pos.x.toFixed(1)),
        y: Number(pos.y.toFixed(1)),
        z: Number(pos.z.toFixed(1)),
      },
      yaw: bot.entity.yaw ?? 0,
      pitch: bot.entity.pitch ?? 0,
      dimension: String(bot.game?.dimension ?? "overworld"),
      biome,
      timeOfDay: Number(bot.time?.timeOfDay ?? 6000),
      health: Math.round(bot.health ?? 20),
      food: Math.round(bot.food ?? 20),
      heldSlot: bot.quickBarSlot ?? 0,
      slots,
      blocks: blocks.slice(0, 480),
      entities: entities.slice(0, 40),
    };
  }

  public lookRelative(yawDelta: number, pitchDelta: number) {
    if (!this.bot || this.status !== "online" || !this.bot.entity) return;
    const nextYaw = (this.bot.entity.yaw ?? 0) + yawDelta;
    const nextPitch = Math.max(-1.4, Math.min(1.4, (this.bot.entity.pitch ?? 0) + pitchDelta));
    void this.bot.look(nextYaw, nextPitch, true).catch(() => undefined);
  }

  public setInGameChatListener(
    listener: (sender: string, message: string, isSystem: boolean) => void
  ) {
    this.inGameChatListener = listener;
  }

  private recordInGameChat(
    sender: string,
    message: string,
    isBot: boolean,
    isSystem: boolean
  ) {
    const cleanMsg = message.trim();
    if (!cleanMsg) return;

    const dedupKey = `${sender}:${cleanMsg}`;
    const now = Date.now();
    const prev = this.recentChatDedup.get(dedupKey);
    if (prev && now - prev < 1500) {
      return;
    }
    this.recentChatDedup.set(dedupKey, now);
    if (this.recentChatDedup.size > 60) {
      for (const [k, ts] of this.recentChatDedup) {
        if (now - ts > 10000) this.recentChatDedup.delete(k);
      }
    }

    const entry: InGameChatMessage = {
      id: `${now}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: formatClock(),
      sender,
      message: cleanMsg,
      isBot,
      isSystem,
    };
    this.inGameChat = [...this.inGameChat, entry].slice(-60);
    this.pushLog(
      "chat",
      isSystem ? `[Server] ${cleanMsg}` : `[O'yin chati] <${sender}> ${cleanMsg}`
    );

    if (!isBot && this.inGameChatListener) {
      this.inGameChatListener(sender, cleanMsg, isSystem);
    }
  }

  public connect(customConfig?: Partial<BotConfig>): BotStateSnapshot {
    if (customConfig) {
      this.updateConfig(customConfig);
    }
    this.manualDisconnect = false;
    this.clearTimers();
    this.teardownBot();

    const { host, port, display } = parseServerAddress(this.config.serverLink);
    const mcVersion = parseMinecraftVersion(this.config.versionLabel);

    this.status = "connecting";
    this.statusMessage = `${display} manziliga ${this.config.versionLabel} (Cracked) orqali ulanilmoqda...`;
    this.pushLog("info", this.statusMessage);

    try {
      const bot = mineflayer.createBot({
        host,
        ...(port ? { port } : {}),
        username: this.config.username,
        auth: "offline",
        version: mcVersion,
        hideErrors: false,
        checkTimeoutInterval: 20000,
      });

      this.bot = bot;
      bot.loadPlugin(pathfinder);
      this.voiceChatBridge.attachToBot(bot, host, this.config.useSimpleVoiceChat);

      // Fabric Loader & Fabric API (1.21.x) configuration handshake support
      bot._client.on("packet", (data: { channel?: string; data?: Buffer }, meta: { state?: string; name?: string }) => {
        if (meta.state !== "configuration" || meta.name !== "custom_payload" || !data?.channel) {
          return;
        }
        try {
          if (data.channel === "minecraft:register") {
            const incoming = Buffer.isBuffer(data.data)
              ? data.data.toString("utf8")
              : "";
            if (incoming.includes("fabric:") || incoming.includes("c:version")) {
              const chans = [
                "c:version",
                "c:register",
                "fabric:registry/sync",
                "fabric:registry/sync/direct",
                "fabric:registry/sync/complete",
                "fabric:accepted_attachments_v1",
              ].join("\0");
              bot._client.write("custom_payload", {
                channel: "minecraft:register",
                data: Buffer.from(chans, "utf8"),
              });
            }
          } else if (data.channel === "c:version" && data.data) {
            bot._client.write("custom_payload", {
              channel: "c:version",
              data: data.data,
            });
          } else if (data.channel === "c:register" && data.data) {
            bot._client.write("custom_payload", {
              channel: "c:register",
              data: data.data,
            });
          } else if (
            data.channel === "fabric:registry/sync" ||
            data.channel === "fabric:registry/sync/direct"
          ) {
            bot._client.write("custom_payload", {
              channel: "fabric:registry/sync/complete",
              data: Buffer.alloc(0),
            });
          } else if (data.channel === "fabric:accepted_attachments_v1") {
            bot._client.write("custom_payload", {
              channel: "fabric:accepted_attachments_v1",
              data: Buffer.from([0]),
            });
          }
        } catch {
          // Ignore if client socket closed mid-handshake
        }
      });

      bot.once("spawn", () => {
        this.status = "online";
        this.connectedAt = Date.now();
        this.statusMessage = `${display} serverida faol (${this.config.username} · Cracked)`;
        this.pushLog("success", `Bot serverga kirdi! Versiya: ${bot.version}, Rejim: Cracked.`);

        try {
          const defaultMovements = new Movements(bot);
          defaultMovements.canDig = true;
          defaultMovements.allow1by1towers = true;
          bot.pathfinder.setMovements(defaultMovements);
        } catch (err) {
          this.pushLog("warn", `Harakat sozlamasida ogohlantirish: ${String(err)}`);
        }

        if (this.activeTask !== "idle") {
          this.startTaskLoop();
        }
        this.broadcast();
      });

      bot.on("chat", (username, message) => {
        if (username === bot.username) return;
        this.recordInGameChat(username, message, false, false);
      });

      bot.on("messagestr", (msgText, position) => {
        const clean = (msgText || "").trim();
        if (!clean || position === "game_info") return;

        const pass = this.config.authPassword;
        const lower = clean.toLowerCase();
        if (pass) {
          if (lower.includes("/register")) {
            bot.chat(`/register ${pass} ${pass}`);
            this.pushLog("info", "AuthMe: Avtomatik /register yuborildi.");
          } else if (lower.includes("/login")) {
            bot.chat(`/login ${pass}`);
            this.pushLog("info", "AuthMe: Avtomatik /login yuborildi.");
          }
        }

        const angleMatch = clean.match(/^<([^>]{1,20})>\s+(.+)$/);
        const bracketMatch = clean.match(/^\[([^\]]{1,20})\]\s+(.+)$/);
        const colonMatch = clean.match(/^([A-Za-z0-9_]{2,16}):\s+(.+)$/);
        const matched = angleMatch || bracketMatch || colonMatch;

        if (matched) {
          const sender = matched[1].trim();
          const body = matched[2].trim();
          if (sender === bot.username) return;
          this.recordInGameChat(sender, body, false, false);
        } else if (!clean.startsWith(`<${bot.username}>`)) {
          this.recordInGameChat("Server", clean, false, true);
        }
      });

      bot.on("health", () => {
        this.broadcast();
      });

      bot.on("kicked", (reason) => {
        const uzReason = formatKickReasonUz(reason);
        this.pushLog("error", `Serverdan chiqarildi: ${uzReason}`);
        this.handleDisconnect(uzReason);
      });

      bot.on("error", (err: NodeJS.ErrnoException) => {
        let friendly = err.message || "Noma'lum ulanish xatosi";
        if (err.code === "ENOTFOUND") {
          friendly = `${host} manzili topilmadi (e4mc tunnel hozir yopiq bo'lishi mumkin).`;
        } else if (err.code === "ECONNREFUSED") {
          friendly = `${display} ulanishni rad etdi (server o'chirilgan yoki port yopiq).`;
        } else if (err.code === "ETIMEDOUT") {
          friendly = `${display} javob bermadi (vaqt tugadi).`;
        }
        this.pushLog("error", `Ulanish xatosi: ${friendly}`);
        this.handleDisconnect(friendly);
      });

      bot.on("end", (reason) => {
        if (!this.manualDisconnect && this.status !== "reconnecting") {
          this.handleDisconnect(`Aloqa uzildi (${reason || "tarmoq"})`);
        }
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      this.status = "error";
      this.statusMessage = `Botni ishga tushirishda xatolik: ${msg}`;
      this.pushLog("error", this.statusMessage);
      this.scheduleReconnectIf247();
    }

    return this.getSnapshot();
  }

  private handleDisconnect(reason: string) {
    this.teardownBot();
    this.connectedAt = null;

    if (this.manualDisconnect) {
      this.status = "offline";
      this.statusMessage = "Bot foydalanuvchi tomonidan uzildi.";
      this.broadcast();
      return;
    }

    if (this.config.autoReconnect247) {
      this.status = "reconnecting";
      this.statusMessage = `24/7 qayta ulanish kutilmoqda: ${reason}`;
      this.scheduleReconnectIf247();
    } else {
      this.status = "error";
      this.statusMessage = reason;
    }
    this.broadcast();
  }

  private scheduleReconnectIf247() {
    if (this.manualDisconnect || !this.config.autoReconnect247) return;
    if (this.reconnectTimer) return;

    const delayMs = Math.min(30000, 7000 + this.reconnectCount * 3000);
    this.pushLog(
      "warn",
      `24/7 Watchdog: ${Math.round(delayMs / 1000)} soniyadan keyin qayta ulaniladi...`
    );

    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (!this.manualDisconnect && this.config.autoReconnect247) {
        this.reconnectCount += 1;
        this.connect();
      }
    }, delayMs);
  }

  public disconnect(): BotStateSnapshot {
    this.manualDisconnect = true;
    this.clearTimers();
    this.teardownBot();
    this.connectedAt = null;
    this.status = "offline";
    this.activeTask = "idle";
    this.taskDetail = "Kutish holatida";
    this.statusMessage = "Bot uzildi.";
    this.pushLog("info", "Bot serverdan uzildi.");
    return this.getSnapshot();
  }

  private clearTimers() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.taskLoopTimer) {
      clearInterval(this.taskLoopTimer);
      this.taskLoopTimer = null;
    }
  }

  private teardownBot() {
    this.voiceChatBridge.cleanup();
    if (this.bot) {
      try {
        this.bot.pathfinder?.stop();
      } catch {
        // ignore
      }
      try {
        this.bot.removeAllListeners();
        this.bot.quit();
      } catch {
        // ignore
      }
      this.bot = null;
    }
  }

  public sayInGame(message: string): boolean {
    const clean = message.trim().slice(0, 220);
    if (!clean) return false;
    if (this.bot && this.status === "online") {
      try {
        this.bot.chat(clean);
        this.recordInGameChat(this.config.username, clean, true, false);
        return true;
      } catch (err) {
        this.pushLog("error", `Chat yuborishda xato: ${String(err)}`);
      }
    }
    return false;
  }

  public cancelCurrentTask(announce = true): BotStateSnapshot {
    this.activeTask = "idle";
    this.targetCount = null;
    this.collectedCount = 0;
    this.taskDetail = "Aytilgan ish bekor qilindi";

    if (this.taskLoopTimer) {
      clearInterval(this.taskLoopTimer);
      this.taskLoopTimer = null;
    }
    if (this.bot && this.status === "online") {
      try {
        this.bot.pathfinder.stop();
        this.bot.stopDigging();
      } catch {
        // ignore
      }
    }
    this.pushLog("info", "Aytilgan ish bekor qilindi.");
    if (announce && this.status === "online") {
      this.sayInGame("Xo'p, aytilgan ish bekor qilindi.");
    }
    this.broadcast();
    return this.getSnapshot();
  }

  public setTask(
    task: BotTaskMode,
    targetPlayer?: string,
    targetCount?: number | null
  ): BotStateSnapshot {
    this.activeTask = task;
    this.targetCount =
      typeof targetCount === "number" && Number.isFinite(targetCount) && targetCount > 0
        ? Math.min(2304, Math.round(targetCount))
        : null;
    this.collectedCount = 0;

    if (targetPlayer && targetPlayer.trim()) {
      this.config.followTarget = targetPlayer.trim();
    }

    if (this.taskLoopTimer) {
      clearInterval(this.taskLoopTimer);
      this.taskLoopTimer = null;
    }

    if (this.bot && this.status === "online") {
      try {
        this.bot.pathfinder.stop();
      } catch {
        // ignore
      }
    }

    const goalSuffix = this.targetCount ? ` (Maqsad: ${this.targetCount} ta)` : "";

    switch (task) {
      case "idle":
        this.targetCount = null;
        this.taskDetail = "Kutish holatida (vazifa to'xtatildi)";
        this.pushLog("info", "Bot kutish holatiga o'tdi.");
        break;
      case "follow_player":
        this.taskDetail = this.config.followTarget
          ? `${this.config.followTarget} orqasidan yurmoqda`
          : "Eng yaqin o'yinchi orqasidan yurmoqda";
        this.pushLog("info", `Vazifa: ${this.taskDetail}`);
        break;
      case "chop_wood":
        this.taskDetail = `Yaqin atrofdagi daraxtlarni chopmoqda${goalSuffix}`;
        this.pushLog("info", `Vazifa boshlandi: Daraxt chopish${goalSuffix}`);
        break;
      case "speedrun":
        this.speedrunStage = "1-bosqich: Yog'och va dastgoh yig'ish";
        this.taskDetail = "Speedrun rejimi: Ender Dragon sari tezkor rivojlanish";
        this.pushLog("info", "Speedrun rejimi ishga tushirildi!");
        break;
      case "mine_ores":
        this.taskDetail = `Yer osti resurslari va toshlarni qazmoqda${goalSuffix}`;
        this.pushLog("info", `Vazifa boshlandi: Kon qazish${goalSuffix}`);
        break;
      case "guard":
        this.taskDetail = "O'yinchi atrofini yovuz moblardan qo'riqlamoqda";
        this.pushLog("info", "Vazifa boshlandi: Qo'riqlash va jang");
        break;
      case "hunt_food":
        this.taskDetail = "Ovqat uchun hayvonlarni ovlamoqda";
        this.pushLog("info", "Vazifa boshlandi: Ovqat ovlash");
        break;
      case "collect_drops":
        this.taskDetail = "Yerdagi tushgan buyumlarni terib olmoqda";
        this.pushLog("info", "Vazifa boshlandi: Buyum yig'ish");
        break;
      case "farm_crops":
        this.taskDetail = "Pishgan ekinlarni yig'ib dehqonchilik qilmoqda";
        this.pushLog("info", "Vazifa boshlandi: Dehqonchilik");
        break;
      case "fish":
        this.taskDetail = "Suv bo'yida baliq tutmoqda";
        this.pushLog("info", "Vazifa boshlandi: Baliq ovlash");
        break;
      case "torch_place":
        this.taskDetail = "Atrofni yoritish uchun mash'ala qo'ymoqda";
        this.pushLog("info", "Vazifa boshlandi: Mash'ala qo'yish");
        break;
      case "sleep_bed":
        this.taskDetail = "Yaqin krovatni topib uxlashga urinmoqda";
        this.pushLog("info", "Vazifa boshlandi: Krovatda uxlash");
        break;
      case "build_pillar":
        this.taskDetail = "Ostiga blok qo'yib himoya ustuni qurmoqda";
        this.pushLog("info", "Vazifa boshlandi: Ustun qurish");
        break;
    }

    if (task !== "idle" && this.status === "online") {
      this.startTaskLoop();
    }
    this.broadcast();
    return this.getSnapshot();
  }

  private startTaskLoop() {
    if (this.taskLoopTimer) {
      clearInterval(this.taskLoopTimer);
    }
    void this.runTaskTick();
    this.taskLoopTimer = setInterval(() => {
      void this.runTaskTick();
    }, 2500);
  }

  private findTargetPlayerEntity() {
    if (!this.bot) return null;
    const preferred = this.config.followTarget.trim();
    if (preferred && this.bot.players[preferred]?.entity) {
      return this.bot.players[preferred].entity;
    }
    let nearest: ReturnType<Bot["nearestEntity"]> = null;
    let bestDist = Infinity;
    for (const [name, info] of Object.entries(this.bot.players)) {
      if (name === this.bot.username || !info?.entity) continue;
      const dist = this.bot.entity.position.distanceTo(info.entity.position);
      if (dist < bestDist) {
        bestDist = dist;
        nearest = info.entity;
      }
    }
    return nearest;
  }

  private async equipBestToolFor(blockName: string) {
    if (!this.bot) return;
    const isLog = blockName.includes("log");
    const preferredOrder = isLog
      ? ["netherite_axe", "diamond_axe", "iron_axe", "stone_axe", "wooden_axe"]
      : ["netherite_pickaxe", "diamond_pickaxe", "iron_pickaxe", "stone_pickaxe", "wooden_pickaxe"];

    for (const toolName of preferredOrder) {
      const item = this.bot.inventory.items().find((i) => i.name === toolName);
      if (item) {
        try {
          await this.bot.equip(item, "hand");
        } catch {
          // ignore
        }
        return;
      }
    }
  }

  private async autoEatIfHungry() {
    if (!this.bot || (this.bot.food ?? 20) > 14) return;
    const foodItem = this.bot.inventory.items().find((i) => EDIBLE_ITEMS.has(i.name));
    if (!foodItem) return;
    try {
      await this.bot.equip(foodItem, "hand");
      await this.bot.consume();
      this.pushLog("info", `Bot ovqatlandi: ${foodItem.name}`);
    } catch {
      // ignore
    }
  }

  private countInventoryLogs(): number {
    if (!this.bot) return 0;
    return this.bot.inventory
      .items()
      .filter((i) => LOG_NAMES.includes(i.name) || i.name.endsWith("_log"))
      .reduce((sum, i) => sum + i.count, 0);
  }

  private countInventoryOresAndStone(): number {
    if (!this.bot) return 0;
    return this.bot.inventory
      .items()
      .filter(
        (i) =>
          ORE_NAMES.includes(i.name) ||
          i.name.includes("raw_") ||
          i.name === "coal" ||
          i.name === "diamond"
      )
      .reduce((sum, i) => sum + i.count, 0);
  }

  private async ensureToolCrafted(kind: "axe" | "pickaxe") {
    if (!this.bot) return;
    const bot = this.bot;
    const hasTool = bot.inventory
      .items()
      .some((i) => i.name.endsWith(`_${kind}`));
    if (hasTool) return;

    const regItems = bot.registry?.itemsByName;
    if (!regItems) return;

    try {
      // 1. Ensure planks from any logs
      const totalPlanks = () =>
        bot.inventory
          .items()
          .filter((i) => i.name.endsWith("_planks"))
          .reduce((s, i) => s + i.count, 0);

      if (totalPlanks() < 7) {
        const logItem = bot.inventory
          .items()
          .find((i) => i.name.endsWith("_log"));
        if (logItem) {
          const plankName = logItem.name.replace(/_log$/, "_planks");
          const plankMeta = regItems[plankName] || regItems["oak_planks"];
          if (plankMeta) {
            const recipes = bot.recipesFor(plankMeta.id, null, 1, null);
            if (recipes.length > 0) {
              await bot.craft(recipes[0], Math.min(2, logItem.count), undefined);
            }
          }
        }
      }

      if (totalPlanks() < 6) return;

      // 2. Ensure sticks
      const stickCount = () =>
        bot.inventory
          .items()
          .filter((i) => i.name === "stick")
          .reduce((s, i) => s + i.count, 0);

      if (stickCount() < 2 && regItems["stick"]) {
        const recipes = bot.recipesFor(regItems["stick"].id, null, 1, null);
        if (recipes.length > 0) {
          await bot.craft(recipes[0], 1, undefined);
        }
      }

      if (stickCount() < 2 || totalPlanks() < 3) return;

      // 3. Find or place a crafting_table
      let tableBlock = bot.findBlock({
        matching: (b) => b.name === "crafting_table",
        maxDistance: 8,
      });

      if (!tableBlock && regItems["crafting_table"]) {
        let tableItem = bot.inventory.items().find((i) => i.name === "crafting_table");
        if (!tableItem) {
          const tableRecipes = bot.recipesFor(regItems["crafting_table"].id, null, 1, null);
          if (tableRecipes.length > 0) {
            await bot.craft(tableRecipes[0], 1, undefined);
            tableItem = bot.inventory.items().find((i) => i.name === "crafting_table");
          }
        }
        if (tableItem) {
          const placeOffsets = [
            [1, 0, 0],
            [-1, 0, 0],
            [0, 0, 1],
            [0, 0, -1],
          ];
          for (const [ox, , oz] of placeOffsets) {
            const support = bot.blockAt(bot.entity.position.offset(ox, -1, oz));
            const targetAir = bot.blockAt(bot.entity.position.offset(ox, 0, oz));
            if (
              support &&
              support.name !== "air" &&
              targetAir &&
              targetAir.name === "air"
            ) {
              await bot.equip(tableItem, "hand");
              await bot.placeBlock(support, { x: 0, y: 1, z: 0 } as never);
              tableBlock = bot.blockAt(bot.entity.position.offset(ox, 0, oz));
              break;
            }
          }
        }
      }

      if (!tableBlock) return;
      if (bot.entity.position.distanceTo(tableBlock.position) > 3.5) {
        await bot.pathfinder.goto(
          new goals.GoalNear(tableBlock.position.x, tableBlock.position.y, tableBlock.position.z, 2)
        );
      }

      const cobble = bot.inventory
        .items()
        .filter((i) => i.name === "cobblestone")
        .reduce((s, i) => s + i.count, 0);

      const candidates =
        cobble >= 3 ? [`stone_${kind}`, `wooden_${kind}`] : [`wooden_${kind}`];

      for (const toolName of candidates) {
        const meta = regItems[toolName];
        if (!meta) continue;
        const recipes = bot.recipesFor(meta.id, null, 1, tableBlock);
        if (recipes.length > 0) {
          await bot.craft(recipes[0], 1, tableBlock);
          const uzTool = kind === "axe" ? "Bolta" : "Kirkka";
          this.pushLog("success", `${uzTool} (${toolName}) yasaldi! Ish davom etmoqda.`);
          if (this.config.relayAiToGameChat) {
            this.sayInGame(`${uzTool} yasadim, endi tezroq qaziyman!`);
          }
          break;
        }
      }
    } catch {
      // If crafting fails due to moving or missing materials, continue digging by hand
    }
  }

  private async runTaskTick() {
    if (!this.bot || this.status !== "online" || this.isTaskStepRunning) return;
    if (this.activeTask === "idle") return;

    this.isTaskStepRunning = true;
    try {
      const bot = this.bot;
      await this.autoEatIfHungry();

      if (this.activeTask === "follow_player") {
        const target = this.findTargetPlayerEntity();
        if (!target) {
          this.taskDetail = "O'yinchi ko'rinish zonasida kutilmoqda...";
          this.broadcast();
          return;
        }
        this.taskDetail = `${target.username || "O'yinchi"} orqasidan yurmoqda (${Math.round(
          bot.entity.position.distanceTo(target.position)
        )} blok)`;
        bot.pathfinder.setGoal(new goals.GoalFollow(target, 2), true);
        this.broadcast();
        return;
      }

      if (this.activeTask === "guard") {
        const hostile = bot.nearestEntity(
          (entity) =>
            Boolean(entity.name && HOSTILE_MOBS.has(entity.name)) &&
            entity.position.distanceTo(bot.entity.position) < 16
        );
        if (hostile) {
          this.taskDetail = `Hujum qilmoqda: ${hostile.name}`;
          const sword = bot.inventory
            .items()
            .find((i) => i.name.includes("sword") || i.name.includes("axe"));
          if (sword) {
            await bot.equip(sword, "hand").catch(() => undefined);
          }
          bot.pathfinder.setGoal(new goals.GoalFollow(hostile, 1.5), true);
          if (bot.entity.position.distanceTo(hostile.position) <= 3.5) {
            bot.attack(hostile);
          }
        } else {
          const target = this.findTargetPlayerEntity();
          if (target) {
            this.taskDetail = `${target.username || "O'yinchi"} yonida qo'riqlamoqda`;
            bot.pathfinder.setGoal(new goals.GoalFollow(target, 3), true);
          } else {
            this.taskDetail = "Atrof tinch — dushman qidirilmoqda";
          }
        }
        this.broadcast();
        return;
      }

      if (this.activeTask === "hunt_food") {
        const animal = bot.nearestEntity(
          (entity) =>
            Boolean(entity.name && FOOD_ANIMALS.has(entity.name)) &&
            entity.position.distanceTo(bot.entity.position) < 28
        );
        if (!animal) {
          this.taskDetail = "Yaqin atrofda hayvon topilmadi";
          this.broadcast();
          return;
        }
        this.taskDetail = `Ovlanmoqda: ${animal.name}`;
        const weapon = bot.inventory
          .items()
          .find((i) => i.name.includes("sword") || i.name.includes("axe"));
        if (weapon) {
          await bot.equip(weapon, "hand").catch(() => undefined);
        }
        bot.pathfinder.setGoal(new goals.GoalFollow(animal, 1.5), true);
        if (bot.entity.position.distanceTo(animal.position) <= 3.5) {
          bot.attack(animal);
        }
        this.broadcast();
        return;
      }

      if (this.activeTask === "collect_drops") {
        const drop = bot.nearestEntity(
          (entity) =>
            (entity.name === "item" || entity.displayName === "Item") &&
            entity.position.distanceTo(bot.entity.position) < 24
        );
        if (!drop) {
          this.taskDetail = "Yerdagi tushgan buyumlar ko'rinmadi";
          this.broadcast();
          return;
        }
        this.taskDetail = `Buyumga qarab harakatlanmoqda (${Math.round(
          bot.entity.position.distanceTo(drop.position)
        )} blok)`;
        bot.pathfinder.setGoal(
          new goals.GoalNear(drop.position.x, drop.position.y, drop.position.z, 0.5),
          true
        );
        this.broadcast();
        return;
      }

      if (this.activeTask === "farm_crops") {
        const crop = bot.findBlock({
          matching: (b) => CROP_NAMES.has(b.name),
          maxDistance: 24,
        });
        if (!crop) {
          this.taskDetail = "Yaqin atrofda ekin topilmadi";
          this.broadcast();
          return;
        }
        this.taskDetail = `Ekin yig'ilmoqda: ${crop.name}`;
        this.broadcast();
        await bot.pathfinder.goto(
          new goals.GoalNear(crop.position.x, crop.position.y, crop.position.z, 2)
        );
        if (bot.canDigBlock(crop)) {
          await bot.dig(crop);
          this.blocksMinedCount += 1;
          this.broadcast();
        }
        return;
      }

      if (this.activeTask === "fish") {
        const rod = bot.inventory.items().find((i) => i.name === "fishing_rod");
        if (!rod) {
          this.taskDetail = "Ryukzakda qarmoq (fishing_rod) yo'q";
          this.broadcast();
          return;
        }
        const water = bot.findBlock({
          matching: (b) => b.name === "water",
          maxDistance: 20,
        });
        if (!water) {
          this.taskDetail = "Yaqin atrofda suv topilmadi";
          this.broadcast();
          return;
        }
        await bot.pathfinder.goto(
          new goals.GoalNear(water.position.x, water.position.y + 1, water.position.z, 3)
        );
        await bot.equip(rod, "hand");
        await bot.lookAt(water.position.offset(0.5, 0.5, 0.5));
        this.taskDetail = "Suvga qarmoq tashlandi, baliq kutilmoqda...";
        this.broadcast();
        await bot.fish();
        this.taskDetail = "Baliq tutildi!";
        this.broadcast();
        return;
      }

      if (this.activeTask === "torch_place") {
        const torch = bot.inventory.items().find((i) => i.name === "torch");
        if (!torch) {
          this.taskDetail = "Ryukzakda mash'ala (torch) topilmadi";
          this.broadcast();
          return;
        }
        const ground = bot.blockAt(bot.entity.position.offset(0, -1, 0));
        if (ground && ground.name !== "air") {
          await bot.equip(torch, "hand");
          await bot.placeBlock(ground, { x: 0, y: 1, z: 0 } as never);
          this.taskDetail = "Mash'ala qo'yildi!";
          this.activeTask = "idle";
          this.broadcast();
        }
        return;
      }

      if (this.activeTask === "sleep_bed") {
        const bed = bot.findBlock({
          matching: (b) => b.name.endsWith("_bed"),
          maxDistance: 24,
        });
        if (!bed) {
          this.taskDetail = "Yaqin atrofda krovat topilmadi";
          this.broadcast();
          return;
        }
        await bot.pathfinder.goto(
          new goals.GoalNear(bed.position.x, bed.position.y, bed.position.z, 2)
        );
        await bot.sleep(bed);
        this.taskDetail = "Krovatda uxlamoqda...";
        this.broadcast();
        return;
      }

      if (this.activeTask === "build_pillar") {
        const blockItem = bot.inventory.items().find((i) => BUILD_BLOCKS.includes(i.name));
        if (!blockItem) {
          this.taskDetail = "Qurilish uchun blok (tosh/yog'och/tuproq) topilmadi";
          this.broadcast();
          return;
        }
        await bot.equip(blockItem, "hand");
        const below = bot.blockAt(bot.entity.position.offset(0, -1, 0));
        if (below && below.name !== "air") {
          bot.setControlState("jump", true);
          await new Promise((r) => setTimeout(r, 250));
          await bot.placeBlock(below, { x: 0, y: 1, z: 0 } as never).catch(() => undefined);
          bot.setControlState("jump", false);
          this.taskDetail = `Ustun ko'tarilmoqda (${blockItem.name})`;
          this.broadcast();
        }
        return;
      }

      if (this.activeTask === "chop_wood" || this.activeTask === "speedrun") {
        if (this.activeTask === "chop_wood") {
          await this.ensureToolCrafted("axe");
          const currentLogs = this.countInventoryLogs();
          this.collectedCount = currentLogs;
          if (this.targetCount && currentLogs >= this.targetCount) {
            const doneCount = this.targetCount;
            this.activeTask = "idle";
            this.targetCount = null;
            this.taskDetail = `Maqsad bajarildi: ${doneCount} ta daraxt yig'ildi!`;
            this.pushLog("success", this.taskDetail);
            this.sayInGame(`${doneCount} ta daraxt yig'ib bo'ldim!`);
            this.broadcast();
            return;
          }
        }

        if (this.activeTask === "speedrun") {
          const logsCount = bot.inventory
            .items()
            .filter((i) => i.name.includes("log") || i.name.includes("planks"))
            .reduce((sum, i) => sum + i.count, 0);
          const cobbleCount = bot.inventory
            .items()
            .filter((i) => i.name === "cobblestone")
            .reduce((sum, i) => sum + i.count, 0);
          const ironCount = bot.inventory
            .items()
            .filter((i) => i.name.includes("iron"))
            .reduce((sum, i) => sum + i.count, 0);

          if (logsCount < 12) {
            this.speedrunStage = `1-bosqich: Yog'och yig'ish (${logsCount}/12)`;
          } else if (cobbleCount < 16) {
            this.speedrunStage = `2-bosqich: Tosh qurol va pechka uchun tosh (${cobbleCount}/16)`;
          } else if (ironCount < 8) {
            this.speedrunStage = `3-bosqich: Temir va chelak qidirish (${ironCount}/8)`;
          } else {
            this.speedrunStage = "4-bosqich: Nether portal va Blaze tayyorgarligi";
          }
        }

        const wantCobble =
          this.activeTask === "speedrun" &&
          bot.inventory
            .items()
            .filter((i) => i.name.includes("log") || i.name.includes("planks"))
            .reduce((sum, i) => sum + i.count, 0) >= 12;

        const targetBlock = bot.findBlock({
          matching: (b) =>
            wantCobble ? ORE_NAMES.includes(b.name) : LOG_NAMES.includes(b.name),
          maxDistance: 40,
        });

        if (!targetBlock) {
          this.taskDetail = wantCobble
            ? "Yaqin atrofda tosh/ruda izlanmoqda..."
            : "Yaqin atrofda daraxt izlanmoqda...";
          this.broadcast();
          return;
        }

        const progressLabel =
          this.activeTask === "chop_wood" && this.targetCount
            ? ` (${this.countInventoryLogs()}/${this.targetCount})`
            : "";

        this.taskDetail = `${targetBlock.name} chopilmoqda${progressLabel} (${targetBlock.position.x}, ${targetBlock.position.y}, ${targetBlock.position.z})`;
        this.broadcast();

        await bot.pathfinder.goto(
          new goals.GoalNear(
            targetBlock.position.x,
            targetBlock.position.y,
            targetBlock.position.z,
            2
          )
        );
        await this.equipBestToolFor(targetBlock.name);
        if (bot.canDigBlock(targetBlock)) {
          await bot.dig(targetBlock);
          this.blocksMinedCount += 1;
          if (this.activeTask === "chop_wood") {
            const afterLogs = this.countInventoryLogs();
            this.collectedCount = afterLogs;
            if (this.targetCount && afterLogs >= this.targetCount) {
              const doneCount = this.targetCount;
              this.activeTask = "idle";
              this.targetCount = null;
              this.taskDetail = `Maqsad bajarildi: ${doneCount} ta daraxt yig'ildi!`;
              this.pushLog("success", this.taskDetail);
              this.sayInGame(`${doneCount} ta daraxt yig'ib bo'ldim!`);
              this.broadcast();
              return;
            }
            this.taskDetail = `Daraxt chopildi (${afterLogs}${
              this.targetCount ? `/${this.targetCount}` : ""
            } ta)`;
          } else {
            this.taskDetail = `Qazib olindi: ${targetBlock.name} (Jami: ${this.blocksMinedCount})`;
          }
          this.broadcast();
        }
        return;
      }

      if (this.activeTask === "mine_ores") {
        await this.ensureToolCrafted("pickaxe");
        const currentOres = this.countInventoryOresAndStone();
        this.collectedCount = currentOres;
        if (this.targetCount && currentOres >= this.targetCount) {
          const doneCount = this.targetCount;
          this.activeTask = "idle";
          this.targetCount = null;
          this.taskDetail = `Maqsad bajarildi: ${doneCount} ta resurs qazildi!`;
          this.pushLog("success", this.taskDetail);
          this.sayInGame(`${doneCount} ta resurs yig'ib bo'ldim!`);
          this.broadcast();
          return;
        }

        const oreBlock = bot.findBlock({
          matching: (b) => ORE_NAMES.includes(b.name),
          maxDistance: 36,
        });
        if (!oreBlock) {
          this.taskDetail = "Yaqin atrofda ruda yoki tosh topilmadi";
          this.broadcast();
          return;
        }
        this.taskDetail = `Qazilmoqda: ${oreBlock.name}${
          this.targetCount ? ` (${currentOres}/${this.targetCount})` : ""
        }`;
        this.broadcast();
        await bot.pathfinder.goto(
          new goals.GoalNear(oreBlock.position.x, oreBlock.position.y, oreBlock.position.z, 2)
        );
        await this.equipBestToolFor(oreBlock.name);
        if (bot.canDigBlock(oreBlock)) {
          await bot.dig(oreBlock);
          this.blocksMinedCount += 1;
          this.collectedCount = this.countInventoryOresAndStone();
          this.broadcast();
        }
      }
    } catch {
      // Path interrupted or block disappeared; next tick retries cleanly
    } finally {
      this.isTaskStepRunning = false;
    }
  }
}

export const botManager = new MinecraftBotManager();
