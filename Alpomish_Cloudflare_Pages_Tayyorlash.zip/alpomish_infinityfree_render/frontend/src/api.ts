// API manzili: mahalliy ishlab chiqishda nisbiy, hostingda VITE_API_BASE_URL orqali beriladi.
const configuredBase = (import.meta.env.VITE_API_BASE_URL || "").trim();
export const API_BASE = configuredBase.replace(/\/$/, "");
export const apiUrl = (path: string) => `${API_BASE}${path.startsWith("/") ? path : `/${path}`}`;
