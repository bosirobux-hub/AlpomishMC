ALPOMISH MC — INFINITYFREE FRONTEND + NODE.JS BACKEND

ZIP ichida:
- frontend/: InfinityFree'ga yuklanadigan React/Vite sayt manbasi.
- backend/: Minecraft bot va Gemini AI API (Node.js).

1) BACKENDNI ISHGA TUSHIRISH
- ZIP'ni ochib, ichidagi barcha fayl/papkalarni GitHub repository'ga joylashtiring (backend va frontend papkalari hamda root render.yaml).
- Render'da New > Blueprint orqali shu repository'ni ulang. render.yaml backend papkasini avtomatik tanlaydi. Agar Web Service'ni qo'lda yaratsangiz Root Directory = backend deb belgilang.
- Build command: npm install
- Start command: npm start
- Environment Variables:
  NODE_ENV=production
  GEMINI_API_KEY=Gemini API kalitingiz
  FRONTEND_ORIGIN=https://SIZNING-SAYTINGIZ.infinityfreeapp.com
- Deploy tugagach https://BACKEND-MANZIL/health manzilini tekshiring.

2) FRONTENDNI INFINITYFREE'GA JOYLASH
- frontend/.env.production ichidagi VITE_API_BASE_URL qiymatini Render backend manzilingizga almashtiring.
- Kompyuterda Node.js o'rnatilgan bo'lsin.
- Terminalda frontend papkaga o'ting va bajaring:
  npm install
  npm run build
- frontend/dist ichidagi hamma fayl/papkalarni InfinityFree htdocs ichiga yuklang.

3) XAVFSIZLIK
- GEMINI_API_KEY ni frontend fayllariga yozmang. Faqat backend Environment Variables ichida saqlang.
- GitHub repository'ni Private qiling.
- Minecraft server paroli yoki boshqa maxfiy ma'lumotlarni ommaviy joylamang.

MUHIM: 100% BEPUL 24/7 KAFOLAT YO'Q
InfinityFree Node.js, API server yoki Minecraft botni ishlatmaydi; u faqat tayyor frontend fayllarini joylaydi.
Render bepul Node web-servisi 15 daqiqa trafik bo'lmasa uxlaydi va keyingi so'rovda uyg'onishi taxminan bir daqiqa oladi. Bepul servis istalgan payt restart bo'lishi ham mumkin. Shu sababli AI/Minecraft bot uzluksiz 24/7 ishlashiga bepul tarifda kafolat berib bo'lmaydi.

Sayt frontend'i InfinityFree'da, API/bot esa alohida Node.js hostda ishlaydi.
