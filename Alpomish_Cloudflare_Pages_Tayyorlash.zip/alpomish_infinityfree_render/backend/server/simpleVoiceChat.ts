import crypto from "crypto";
import dgram from "dgram";
import OpusScript from "opusscript";
import type { Bot } from "mineflayer";
import { SimpleVoiceChatStatus } from "./types.js";

const MAGIC_BYTE = 0xff;
const PACKET_MIC = 0x01;
const PACKET_AUTHENTICATE = 0x05;
const PACKET_AUTHENTICATE_ACK = 0x06;
const PACKET_KEEP_ALIVE = 0x08;
const COMPATIBILITY_VERSION = 18;

interface VoiceChatSession {
  secret: Buffer;
  playerUuid: Buffer;
  serverPort: number;
  voiceHost: string;
  keepAliveMs: number;
}

function writeVarInt(value: number): Buffer {
  const bytes: number[] = [];
  let v = value >>> 0;
  while (true) {
    if ((v & ~0x7f) === 0) {
      bytes.push(v);
      break;
    }
    bytes.push((v & 0x7f) | 0x80);
    v >>>= 7;
  }
  return Buffer.from(bytes);
}

function readVarInt(buf: Buffer, offset: number): { value: number; next: number } {
  let numRead = 0;
  let result = 0;
  let read = 0;
  do {
    if (offset + numRead >= buf.length) {
      return { value: 0, next: buf.length };
    }
    read = buf[offset + numRead];
    result |= (read & 0x7f) << (7 * numRead);
    numRead += 1;
  } while ((read & 0x80) !== 0 && numRead < 5);
  return { value: result, next: offset + numRead };
}

function parseSecretPayload(buf: Buffer, fallbackHost: string): VoiceChatSession | null {
  try {
    if (buf.length < 45) return null;
    let offset = 0;
    const secret = Buffer.from(buf.subarray(offset, offset + 16));
    offset += 16;

    const serverPort = buf.readInt32BE(offset);
    offset += 4;

    const playerUuid = Buffer.from(buf.subarray(offset, offset + 16));
    offset += 16;

    // codec (1 byte), mtuSize (4 bytes), voiceChatDistance (8 bytes)
    offset += 1 + 4 + 8;

    const keepAliveMs = offset + 4 <= buf.length ? buf.readInt32BE(offset) : 1000;
    offset += 4;

    // groupsEnabled (1 byte)
    offset += 1;

    let voiceHost = fallbackHost;
    if (offset < buf.length) {
      const { value: strLen, next } = readVarInt(buf, offset);
      offset = next;
      if (strLen > 0 && offset + strLen <= buf.length) {
        const parsedHost = buf.subarray(offset, offset + strLen).toString("utf8").trim();
        if (parsedHost) {
          voiceHost = parsedHost;
        }
      }
    }

    if (serverPort <= 0 || serverPort > 65535) return null;
    return {
      secret,
      playerUuid,
      serverPort,
      voiceHost,
      keepAliveMs: Math.max(500, Math.min(10000, keepAliveMs || 1000)),
    };
  } catch {
    return null;
  }
}

function encryptAes128Cbc(secret: Buffer, payload: Buffer): Buffer {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv("aes-128-cbc", secret, iv);
  const encrypted = Buffer.concat([cipher.update(payload), cipher.final()]);
  return Buffer.concat([iv, encrypted]);
}

function decryptAes128Cbc(secret: Buffer, encryptedWithIv: Buffer): Buffer | null {
  try {
    if (encryptedWithIv.length < 32) return null;
    const iv = encryptedWithIv.subarray(0, 16);
    const body = encryptedWithIv.subarray(16);
    const decipher = crypto.createDecipheriv("aes-128-cbc", secret, iv);
    return Buffer.concat([decipher.update(body), decipher.final()]);
  } catch {
    return null;
  }
}

function parseWavToMonoPcm48k(wavBuffer: Buffer): Int16Array | null {
  if (wavBuffer.length < 44) return null;
  if (wavBuffer.toString("ascii", 0, 4) !== "RIFF") return null;

  let sampleRate = 24000;
  let channels = 1;
  let bitsPerSample = 16;
  let dataOffset = 44;
  let dataSize = wavBuffer.length - 44;

  let offset = 12;
  while (offset + 8 <= wavBuffer.length) {
    const chunkId = wavBuffer.toString("ascii", offset, offset + 4);
    const chunkSize = wavBuffer.readUInt32LE(offset + 4);
    const bodyStart = offset + 8;
    if (chunkId === "fmt " && bodyStart + 16 <= wavBuffer.length) {
      channels = wavBuffer.readUInt16LE(bodyStart + 2) || 1;
      sampleRate = wavBuffer.readUInt32LE(bodyStart + 4) || 24000;
      bitsPerSample = wavBuffer.readUInt16LE(bodyStart + 14) || 16;
    } else if (chunkId === "data") {
      dataOffset = bodyStart;
      dataSize = Math.min(chunkSize, wavBuffer.length - bodyStart);
      break;
    }
    offset = bodyStart + chunkSize + (chunkSize % 2);
  }

  if (bitsPerSample !== 16 || dataSize < 2) return null;

  const totalFrames = Math.floor(dataSize / (2 * channels));
  const monoSrc = new Float32Array(totalFrames);
  for (let i = 0; i < totalFrames; i += 1) {
    let sum = 0;
    for (let ch = 0; ch < channels; ch += 1) {
      sum += wavBuffer.readInt16LE(dataOffset + (i * channels + ch) * 2);
    }
    monoSrc[i] = sum / channels;
  }

  if (sampleRate === 48000) {
    const exact = new Int16Array(totalFrames);
    for (let i = 0; i < totalFrames; i += 1) {
      exact[i] = Math.max(-32768, Math.min(32767, Math.round(monoSrc[i])));
    }
    return exact;
  }

  const ratio = sampleRate / 48000;
  const outLen = Math.max(1, Math.floor(totalFrames / ratio));
  const resampled = new Int16Array(outLen);
  for (let i = 0; i < outLen; i += 1) {
    const srcPos = i * ratio;
    const idx = Math.floor(srcPos);
    const frac = srcPos - idx;
    const s0 = monoSrc[Math.min(idx, totalFrames - 1)];
    const s1 = monoSrc[Math.min(idx + 1, totalFrames - 1)];
    const val = s0 + (s1 - s0) * frac;
    resampled[i] = Math.max(-32768, Math.min(32767, Math.round(val)));
  }
  return resampled;
}

export class SimpleVoiceChatBridge {
  private socket: dgram.Socket | null = null;
  private session: VoiceChatSession | null = null;
  private keepAliveTimer: NodeJS.Timeout | null = null;
  private fallbackTimer: NodeJS.Timeout | null = null;
  private opus: OpusScript | null = null;
  private sequenceNumber = 0n;
  private authenticated = false;
  private status: SimpleVoiceChatStatus = "inactive";
  private message = "Simple Voice Chat ulanmagan";
  private speaking = false;
  private onStatusChange?: (status: SimpleVoiceChatStatus, msg: string) => void;

  constructor(onStatusChange?: (status: SimpleVoiceChatStatus, msg: string) => void) {
    this.onStatusChange = onStatusChange;
  }

  public getStatus(): { status: SimpleVoiceChatStatus; message: string } {
    return { status: this.status, message: this.message };
  }

  private setStatus(status: SimpleVoiceChatStatus, message: string) {
    this.status = status;
    this.message = message;
    this.onStatusChange?.(status, message);
  }

  public attachToBot(bot: Bot, serverHost: string, enabled: boolean) {
    this.cleanup();
    if (!enabled) {
      this.setStatus("inactive", "Simple Voice Chat sozlamadan o'chirilgan");
      return;
    }

    const handlePayload = (channel: string, rawData: Buffer) => {
      if (channel !== "voicechat:secret" || !Buffer.isBuffer(rawData)) return;
      const parsed = parseSecretPayload(rawData, serverHost);
      if (!parsed) {
        this.setStatus("unsupported", "Simple Voice Chat kalitini o'qib bo'lmadi");
        return;
      }
      if (this.fallbackTimer) {
        clearTimeout(this.fallbackTimer);
        this.fallbackTimer = null;
      }
      this.startUdpSession(parsed);
    };

    bot._client.on("custom_payload", (packet: { channel?: string; data?: Buffer }) => {
      if (packet?.channel && packet?.data) {
        handlePayload(packet.channel, packet.data);
      }
    });

    bot.once("spawn", () => {
      try {
        // Register voicechat channels & request session secret
        const reg = [
          "voicechat:request_secret",
          "voicechat:secret",
          "voicechat:player_state",
          "voicechat:player_states",
        ].join("\0");
        bot._client.write("custom_payload", {
          channel: "minecraft:register",
          data: Buffer.from(reg, "utf8"),
        });

        const reqBuf = Buffer.alloc(4);
        reqBuf.writeInt32BE(COMPATIBILITY_VERSION, 0);
        bot._client.write("custom_payload", {
          channel: "voicechat:request_secret",
          data: reqBuf,
        });

        this.setStatus("requested", "Serverdan Simple Voice Chat ruxsati so'raldi...");

        this.fallbackTimer = setTimeout(() => {
          if (this.status === "requested") {
            this.setStatus(
              "unsupported",
              "Serverda Simple Voice Chat modi aniqlanmadi (ovoz ilova orqali ishlaydi)"
            );
          }
        }, 6500);
      } catch {
        this.setStatus("unsupported", "Simple Voice Chat so'rovini yuborib bo'lmadi");
      }
    });
  }

  private startUdpSession(session: VoiceChatSession) {
    this.session = session;
    this.authenticated = false;
    this.sequenceNumber = 0n;

    try {
      this.opus = new OpusScript(48000, 1, OpusScript.Application.VOIP);
    } catch {
      this.opus = null;
    }

    const sock = dgram.createSocket("udp4");
    this.socket = sock;

    sock.on("message", (msg) => {
      if (!this.session || msg.length < 2 || msg[0] !== MAGIC_BYTE) return;
      const decrypted = decryptAes128Cbc(this.session.secret, msg.subarray(1));
      if (!decrypted || decrypted.length < 1) return;
      const packetType = decrypted[0];
      if (packetType === PACKET_AUTHENTICATE_ACK && !this.authenticated) {
        this.authenticated = true;
        this.setStatus(
          "connected",
          `Simple Voice Chat faol (${session.voiceHost}:${session.serverPort})`
        );
      }
    });

    sock.on("error", () => {
      this.setStatus("unsupported", "Simple Voice Chat UDP portiga ulanib bo'lmadi");
    });

    this.sendAuthPacket();
    this.setStatus(
      "connected",
      `Simple Voice Chat tayyor (${session.voiceHost}:${session.serverPort})`
    );

    this.keepAliveTimer = setInterval(() => {
      this.sendUdpPacket(Buffer.from([PACKET_KEEP_ALIVE]));
    }, session.keepAliveMs);
  }

  private sendAuthPacket() {
    if (!this.session) return;
    const inner = Buffer.concat([
      Buffer.from([PACKET_AUTHENTICATE]),
      this.session.playerUuid,
      this.session.secret,
    ]);
    this.sendUdpPacket(inner);
  }

  private sendUdpPacket(innerPayload: Buffer) {
    if (!this.socket || !this.session) return;
    const encrypted = encryptAes128Cbc(this.session.secret, innerPayload);
    const datagram = Buffer.concat([
      Buffer.from([MAGIC_BYTE]),
      this.session.playerUuid,
      encrypted,
    ]);
    try {
      this.socket.send(datagram, this.session.serverPort, this.session.voiceHost);
    } catch {
      // ignore transient UDP error
    }
  }

  public async speakWav(wavBase64: string): Promise<boolean> {
    if (!this.socket || !this.session || !this.opus || !wavBase64) {
      return false;
    }
    if (this.speaking) return false;
    const wavBuf = Buffer.from(wavBase64, "base64");
    const pcm48k = parseWavToMonoPcm48k(wavBuf);
    if (!pcm48k || pcm48k.length === 0) return false;

    this.speaking = true;
    const FRAME_SAMPLES = 960; // 20ms at 48kHz
    try {
      for (let offset = 0; offset < pcm48k.length; offset += FRAME_SAMPLES) {
        if (!this.socket || !this.session) break;
        const frame = new Int16Array(FRAME_SAMPLES);
        const sliceEnd = Math.min(offset + FRAME_SAMPLES, pcm48k.length);
        frame.set(pcm48k.subarray(offset, sliceEnd));

        const pcmBuf = Buffer.from(frame.buffer, frame.byteOffset, frame.byteLength);
        const opusBytes = this.opus.encode(pcmBuf, FRAME_SAMPLES);

        const seqBuf = Buffer.alloc(8);
        seqBuf.writeBigInt64BE(this.sequenceNumber, 0);
        this.sequenceNumber += 1n;

        const micPayload = Buffer.concat([
          Buffer.from([PACKET_MIC]),
          writeVarInt(opusBytes.length),
          opusBytes,
          seqBuf,
          Buffer.from([0]), // whispering = false
        ]);

        this.sendUdpPacket(micPayload);
        await new Promise((r) => setTimeout(r, 20));
      }
      return true;
    } catch {
      return false;
    } finally {
      this.speaking = false;
    }
  }

  public cleanup() {
    this.speaking = false;
    this.authenticated = false;
    this.session = null;
    if (this.keepAliveTimer) {
      clearInterval(this.keepAliveTimer);
      this.keepAliveTimer = null;
    }
    if (this.fallbackTimer) {
      clearTimeout(this.fallbackTimer);
      this.fallbackTimer = null;
    }
    if (this.socket) {
      try {
        this.socket.close();
      } catch {
        // ignore
      }
      this.socket = null;
    }
    if (this.opus) {
      try {
        this.opus.delete();
      } catch {
        // ignore
      }
      this.opus = null;
    }
  }
}
