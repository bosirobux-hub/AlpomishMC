import { useState } from "react";
import { motion } from "motion/react";
import {
  Backpack,
  Bed,
  Compass,
  Flame,
  Hammer,
  Package,
  Pickaxe,
  Send,
  Shield,
  Square,
  Trees,
  UserCheck,
  Users,
  Utensils,
  Wheat,
  XCircle,
  Zap,
} from "lucide-react";
import { BotStateSnapshot, BotTaskMode } from "../types";

interface TasksPanelProps {
  state: BotStateSnapshot;
  onSetTask: (
    task: BotTaskMode,
    targetPlayer?: string,
    targetCount?: number | null
  ) => Promise<void>;
  onCancelTask: () => Promise<void>;
  onSendGameChat: (msg: string) => Promise<void>;
}

const EASE = [0.22, 1, 0.36, 1] as const;

const MODES: Array<{
  id: BotTaskMode;
  title: string;
  desc: string;
  icon: typeof Zap;
  supportsCount?: boolean;
}> = [
  {
    id: "chop_wood",
    title: "Daraxt Chopish (Bolta yasab)",
    desc: "Daraxt chopadi, yog'ochdan dastgoh va bolta yasab oladi va belgilangan songacha (masalan 64 ta) yig'adi.",
    icon: Trees,
    supportsCount: true,
  },
  {
    id: "mine_ores",
    title: "Kon Qazish (Kirkka yasab)",
    desc: "Kirkka yasab ko'mir, temir, olmos rudalari va toshlarni maqsad songacha qazib yig'adi.",
    icon: Pickaxe,
    supportsCount: true,
  },
  {
    id: "speedrun",
    title: "Speedrun Rejimi",
    desc: "Yog'och, tosh qurollar, temir va Ender Dragon sari bosqichma-bosqich tezkor rivojlanish.",
    icon: Zap,
  },
  {
    id: "follow_player",
    title: "O'yinchi Orqasidan Yurish",
    desc: "Siz yoki do'stlaringiz qayerga borsa, orqadan ergashib hamrohlik qiladi.",
    icon: UserCheck,
  },
  {
    id: "guard",
    title: "Qo'riqlash va Jang",
    desc: "Zombi, skelet, kriper kabi yovuz moblar yaqinlashganda o'yinchini himoya qiladi.",
    icon: Shield,
  },
  {
    id: "hunt_food",
    title: "Ovqat Ovlash",
    desc: "Ochlik tushganda atrofdagi hayvonlarni ovlab go'sht yig'adi.",
    icon: Utensils,
  },
  {
    id: "collect_drops",
    title: "Yerdagi Buyumlarni Terish",
    desc: "Atrofda tushib yotgan barcha blok va buyumlarni yig'ib oladi.",
    icon: Package,
  },
  {
    id: "farm_crops",
    title: "Dehqonchilik",
    desc: "Pishgan bug'doy, sabzi va kartoshka ekinlarini terib oladi.",
    icon: Wheat,
  },
  {
    id: "torch_place",
    title: "Mash'ala Qo'yish",
    desc: "Qorong'i joyda turgan joyiga avtomatik mash'ala o'rnatadi.",
    icon: Flame,
  },
  {
    id: "sleep_bed",
    title: "Krovatda Uxlash",
    desc: "Yaqin krovatni topib tunni xavfsiz o'tkazadi.",
    icon: Bed,
  },
  {
    id: "build_pillar",
    title: "Himoya Ustuni Qurish",
    desc: "Moblardan qochish yoki balandlikka chiqish uchun ostiga blok qo'yadi.",
    icon: Hammer,
  },
  {
    id: "idle",
    title: "Kutish Holati",
    desc: "Barcha harakatlarni to'xtatib, keyingi buyruqni kutadi.",
    icon: Square,
  },
];

export function TasksPanel({
  state,
  onSetTask,
  onCancelTask,
  onSendGameChat,
}: TasksPanelProps) {
  const [chatMsg, setChatMsg] = useState("");
  const [followName, setFollowName] = useState(state.config.followTarget);
  const [goalCountInput, setGoalCountInput] = useState<string>("64");

  const parsedGoal = (() => {
    const n = Number.parseInt(goalCountInput, 10);
    return Number.isFinite(n) && n > 0 ? Math.min(2304, n) : null;
  })();

  const progressPct =
    state.targetCount && state.targetCount > 0
      ? Math.min(100, Math.round((state.collectedCount / state.targetCount) * 100))
      : 0;

  return (
    <div className="space-y-8">
      {/* Active Goal / Cancel Banner */}
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.28, ease: EASE }}
        className="bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4"
      >
        <div className="space-y-1 min-w-0 flex-1">
          <div className="flex items-center gap-2 text-xs text-[#A6A39B]">
            <Compass className="w-3.5 h-3.5 text-[#D97757]" />
            <span>Hozirgi vazifa holati</span>
          </div>
          <div className="text-sm font-semibold text-[#F5F4ED]">{state.taskDetail}</div>
          {state.targetCount && state.targetCount > 0 && (
            <div className="pt-1.5 max-w-md space-y-1">
              <div className="flex items-center justify-between text-xs font-mono tabular-nums text-[#E59377]">
                <span>
                  Yig'ildi: {state.collectedCount} / {state.targetCount} ta
                </span>
                <span>{progressPct}%</span>
              </div>
              <div className="w-full h-2 bg-[#121211] rounded-full overflow-hidden border border-[#2C2B28]">
                <motion.div
                  className="h-full bg-[#D97757]"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPct}%` }}
                  transition={{ type: "spring", stiffness: 260, damping: 28 }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label className="text-xs text-[#A6A39B] whitespace-nowrap">
              Maqsad soni:
            </label>
            <input
              type="number"
              min={1}
              max={2304}
              value={goalCountInput}
              onChange={(e) => setGoalCountInput(e.target.value)}
              placeholder="64"
              className="w-20 px-2.5 py-1.5 bg-[#121211] border border-[#32302C] rounded-xl text-sm font-mono tabular-nums text-[#F5F4ED] focus:outline-none focus:border-[#D97757]"
            />
            {[16, 32, 64].map((preset) => (
              <motion.button
                key={preset}
                type="button"
                whileTap={{ scale: 0.94 }}
                onClick={() => setGoalCountInput(String(preset))}
                className={`px-2.5 py-1.5 rounded-xl border text-xs font-mono tabular-nums transition-colors ${
                  goalCountInput === String(preset)
                    ? "bg-[#D97757]/15 border-[#D97757] text-[#F5F4ED]"
                    : "bg-[#121211] border-[#2C2B28] text-[#9E9B93] hover:text-[#F5F4ED]"
                }`}
              >
                {preset}
              </motion.button>
            ))}
            <motion.button
              type="button"
              whileTap={{ scale: 0.94 }}
              onClick={() => setGoalCountInput("")}
              className={`px-2.5 py-1.5 rounded-xl border text-xs transition-colors ${
                goalCountInput === ""
                  ? "bg-[#D97757]/15 border-[#D97757] text-[#F5F4ED]"
                  : "bg-[#121211] border-[#2C2B28] text-[#9E9B93] hover:text-[#F5F4ED]"
              }`}
            >
              Cheksiz
            </motion.button>
          </div>

          {state.activeTask !== "idle" && (
            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => void onCancelTask()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-xl transition-colors whitespace-nowrap"
            >
              <XCircle className="w-4 h-4" />
              <span>Bekor Qilish</span>
            </motion.button>
          )}
        </div>
      </motion.section>

      {/* Task Selection Grid */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-medium text-[#F5F4ED]">
              Avtonom Minecraft Vazifalari
            </h2>
            <p className="text-sm text-[#A6A39B] mt-1">
              O'yin chatida ham "{state.config.username} daraxt qazi 64 ta" yoki "{state.config.username} bekor qilindi" deb yozishingiz mumkin.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={followName}
              onChange={(e) => setFollowName(e.target.value)}
              placeholder="Ergashiladigan o'yinchi niki..."
              className="px-3 py-2 bg-[#1C1B1A] border border-[#32302C] rounded-xl text-sm text-[#F5F4ED] placeholder:text-[#6E6B64] focus:outline-none focus:border-[#D97757]"
            />
            <motion.button
              type="button"
              whileTap={{ scale: 0.97 }}
              onClick={() => void onSetTask("follow_player", followName)}
              className="px-3.5 py-2 bg-[#292825] hover:bg-[#34322E] border border-[#3B3934] text-[#F5F4ED] text-sm font-medium rounded-xl transition-colors whitespace-nowrap shrink-0"
            >
              Ergashish
            </motion.button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {MODES.map((mode, idx) => {
            const Icon = mode.icon;
            const active = state.activeTask === mode.id;
            return (
              <motion.button
                key={mode.id}
                type="button"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.28, delay: idx * 0.03, ease: EASE }}
                whileHover={{ y: -2.5 }}
                whileTap={{ scale: 0.985 }}
                onClick={() =>
                  void onSetTask(
                    mode.id,
                    followName,
                    mode.supportsCount ? parsedGoal : null
                  )
                }
                className={`text-left p-5 rounded-2xl border transition-colors flex flex-col justify-between gap-4 ${
                  active
                    ? "bg-[#D97757]/14 border-[#D97757]/75"
                    : "bg-[#1C1B1A] border-[#2E2D2A] hover:border-[#45433E]"
                }`}
              >
                <div className="flex items-center justify-between">
                  <Icon
                    className={`w-5 h-5 ${
                      active ? "text-[#D97757]" : "text-[#A6A39B]"
                    }`}
                  />
                  <span
                    className={`text-xs font-mono ${
                      active ? "text-[#E59377]" : "text-[#7C7971]"
                    }`}
                  >
                    {active
                      ? "FAOL"
                      : mode.supportsCount && parsedGoal
                      ? `${parsedGoal} TA BOSHLASH`
                      : "TANLASH"}
                  </span>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-[#F5F4ED]">
                    {mode.title}
                  </h3>
                  <p className="text-sm text-[#A6A39B] mt-1 leading-relaxed">
                    {mode.desc}
                  </p>
                </div>
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* Bottom Split: Players + Inventory + In-Game Chat */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-4 bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#2C2B28] pb-3">
            <h3 className="text-sm font-semibold text-[#F5F4ED] inline-flex items-center gap-2">
              <Users className="w-4 h-4 text-[#D97757]" />
              <span>Serverdagi O'yinchilar</span>
            </h3>
            <span className="text-xs font-mono tabular-nums text-[#9E9B93]">
              {state.nearbyPlayers.length} ta
            </span>
          </div>

          {state.nearbyPlayers.length === 0 ? (
            <p className="text-sm text-[#A6A39B] py-4">
              Hozircha boshqa o'yinchilar ko'rinmadi. Bot serverga ulangach o'yinchilar shu yerda chiqadi.
            </p>
          ) : (
            <div className="space-y-2">
              {state.nearbyPlayers.map((player) => (
                <div
                  key={player}
                  className="flex items-center justify-between px-3 py-2 bg-[#121211] border border-[#2C2B28] rounded-xl text-sm"
                >
                  <span className="font-mono text-[#E5E3DC]">{player}</span>
                  <button
                    type="button"
                    onClick={() => {
                      setFollowName(player);
                      void onSetTask("follow_player", player);
                    }}
                    className="text-xs font-medium text-[#D97757] hover:text-[#E59377]"
                  >
                    Orqasidan yurish
                  </button>
                </div>
              ))}
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!chatMsg.trim()) return;
              void onSendGameChat(chatMsg.trim());
              setChatMsg("");
            }}
            className="pt-3 border-t border-[#2C2B28] space-y-2"
          >
            <label className="block text-xs font-medium text-[#C5C2BA]">
              Bot nomidan o'yin chatiga yozish
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={chatMsg}
                onChange={(e) => setChatMsg(e.target.value)}
                placeholder="Salom do'stlar!"
                className="flex-1 px-3 py-2 bg-[#121211] border border-[#32302C] rounded-xl text-sm text-[#F5F4ED] placeholder:text-[#6E6B64] focus:outline-none focus:border-[#D97757]"
              />
              <motion.button
                type="submit"
                whileTap={{ scale: 0.95 }}
                className="px-3 py-2 bg-[#D97757] hover:bg-[#E38567] text-[#141413] rounded-xl transition-colors"
                aria-label="O'yin chatiga yuborish"
              >
                <Send className="w-4 h-4" />
              </motion.button>
            </div>
          </form>
        </section>

        <section className="lg:col-span-8 bg-[#1C1B1A] border border-[#2E2D2A] rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#2C2B28] pb-3">
            <h3 className="text-sm font-semibold text-[#F5F4ED] inline-flex items-center gap-2">
              <Backpack className="w-4 h-4 text-[#D97757]" />
              <span>Bot Ryukzagi (Qisqacha Inventar)</span>
            </h3>
            <span className="text-xs font-mono tabular-nums text-[#9E9B93]">
              {state.inventory.length} xil buyum
            </span>
          </div>

          {state.inventory.length === 0 ? (
            <div className="py-10 text-center text-sm text-[#A6A39B]">
              Bot ryukzagi hozircha bo'sh. Daraxt chopish yoki kon qazish vazifasini bering.
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {state.inventory.map((item) => (
                <div
                  key={item.name}
                  className="px-3.5 py-2.5 bg-[#121211] border border-[#2C2B28] rounded-xl flex items-center justify-between gap-2"
                >
                  <span className="text-xs font-mono text-[#E5E3DC] truncate">
                    {item.name}
                  </span>
                  <span className="text-xs font-mono font-semibold text-[#E59377] tabular-nums shrink-0">
                    x{item.count}
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
